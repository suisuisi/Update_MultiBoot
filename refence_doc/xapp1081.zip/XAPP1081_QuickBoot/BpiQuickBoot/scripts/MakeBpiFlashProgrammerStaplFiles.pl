##############################################################################
# Copyright � 2013, Xilinx, Inc.
# This design is confidential and proprietary of Xilinx, Inc. All Rights Reserved.
##############################################################################
#   ____  ____
#  /   /\/   /
# /___/  \  /   Vendor: Xilinx
# \   \   \/    Version: 1.00
#  \   \        Filename: MakeBpiFlashProgrammerStaplFiles.pl
#  /   /        Date Last Modified:  January 30, 2013
# /___/   /\    Date Created:        January 30, 2013
# \   \  /  \
#  \___\/\___\
#
#Devices:
#Purpose:
#Usage:
#Reference:
##############################################################################
#
#  Disclaimer: LIMITED WARRANTY AND DISCLAMER. These designs are
#              provided to you "as is." Xilinx and its licensors make and you
#              receive no warranties or conditions, express, implied,
#              statutory or otherwise, and Xilinx specifically disclaims any
#              implied warranties of merchantability, noninfringement, or
#              fitness for a particular purpose. Xilinx does not warrant that
#              the functions contained in these designs will meet your
#              requirements, or that the operation of these designs will be
#              uninterrupted or error free, or that defects in the Designs
#              will be corrected. Furthermore, Xilinx does not warrant or
#              make any representations regarding use or the results of the
#              use of the designs in terms of correctness, accuracy,
#              reliability, or otherwise.
#
#              LIMITATION OF LIABILITY. In no event will Xilinx or its
#              licensors be liable for any loss of data, lost profits, cost
#              or procurement of substitute goods or services, or for any
#              special, incidental, consequential, or indirect damages
#              arising from the use or operation of the designs or
#              accompanying documentation, however caused and on any theory
#              of liability. This limitation will apply even if Xilinx
#              has been advised of the possibility of such damage. This
#              limitation shall apply notwithstanding the failure of the
#              essential purpose of any limited remedies herein.
#
##############################################################################
# Revision History:
#   Revision (YYYY/MM/DD) - [User] Description
#   Rev 1.00 (2013/01/30) - [RMK] Created.
##############################################################################


##############################################################################
# Constants
##############################################################################

# JTAG instructions
$cJtagIRLength  = 6;
$cJtagUser1     = "000010";
$cJtagUser2     = "000011";
$cJtagJProgram  = "001011";

# BPI Flash
$cSizeBlockP30    = 65536;  # words
$cSizeBlockG18    = 131072; # words
$cSizeBuffer      = 512;    # words
$cTimeOutErase    = 4;      # seconds
$cTimeOutProgram  = 0.005;  # seconds

# Hex values
$hexval{"0000"} = "0";
$hexval{"0001"} = "1";
$hexval{"0010"} = "2";
$hexval{"0011"} = "3";
$hexval{"0100"} = "4";
$hexval{"0101"} = "5";
$hexval{"0110"} = "6";
$hexval{"0111"} = "7";
$hexval{"1000"} = "8";
$hexval{"1001"} = "9";
$hexval{"1010"} = "A";
$hexval{"1011"} = "B";
$hexval{"1100"} = "C";
$hexval{"1101"} = "D";
$hexval{"1110"} = "E";
$hexval{"1111"} = "F";
# Binary values
$binval{"0"} = "0000";
$binval{"1"} = "0001";
$binval{"2"} = "0010";
$binval{"3"} = "0011";
$binval{"4"} = "0100";
$binval{"5"} = "0101";
$binval{"6"} = "0110";
$binval{"7"} = "0111";
$binval{"8"} = "1000";
$binval{"9"} = "1001";
$binval{"A"} = "1010";
$binval{"B"} = "1011";
$binval{"C"} = "1100";
$binval{"D"} = "1101";
$binval{"E"} = "1110";
$binval{"F"} = "1111";
$binval{"a"} = "1010";
$binval{"b"} = "1011";
$binval{"c"} = "1100";
$binval{"d"} = "1101";
$binval{"e"} = "1110";
$binval{"f"} = "1111";


##############################################################################
# Globals
##############################################################################
@mcs  = ();

##############################################################################
# Subroutines
##############################################################################

##############################################################################
# Print Help
sub PrintHelp()
{
  print "Perl Script:  $0\n";
  print "Description:  Takes an input BpiFlashProgrammer MCS data file and\n";
  print "  outputs STAPL files for driving the JtagToBpiFlashProgrammer module.\n";
  print "Usage:  perl $0 -tckfreq TF -hir A -tir B -hdr C -tdr D input.mcs\n";
  print " where\n";
  print "   -tckfreq TF = TCK frequency for the tool executing the STAPL. (Default=6)\n";
  print "   -hir A      = header instruction register bit count. (Default=0)\n";
  print "   -tir B      = trailer instruction register bit count. (Default=0)\n";
  print "   -hdr C      = header data register bit count. (Default=0)\n";
  print "   -tdr D      = trailer data register bit count. (Default=0)\n";
  print "   -nosyncword = Do not check sync word erase/program flags\n";
  print "   -device D   = where D=\"P30\" or \"G18\" device (Default=P30)\n";
  print "   -loadfpga   = Reload FPGA after programming update image.\n";
  print "   -maxruntest R = Break long WAITs to multiple, with max R count.\n";
  print "                   (Default R=5000) For no breaks, set R=0\n";
  print "   input.mcs   = File name of input MCS data file.\n";
  exit;
}

##############################################################################
# sub:          subHexToBin
# Input:        $hex = String of hexadecimal characters
#               $len = Length of output binary string
# Output:       String of equivalent binary value.
# Description:  Convert hex to binary.
sub subHexToBin
{
  my $hex = shift(@_);
  my $len = shift(@_);
  if (!$len)
  {
    die "ERROR: Illegal subHexToBin length - $len\n";
  }
  $bin  = "";
  while (length($hex))
  {
    $hexchar  = substr($hex,0,1);
    $binset   = $binval{$hexchar};
    if (!length($binset))
    {
      die "ERROR: Illegal hex character = $hexchar\n";
    }
    $bin  .= $binset;
    $hex  = substr($hex,1);
  }
  while (length($bin)<$len)
  {
    $bin  = "0" . $bin;
  }
  while (length($bin)>$len)
  {
    $bin  = substr($bin,1);
  }
  return $bin;
}

##############################################################################
# sub:          subBinToHex
# Input:        $bin = String of binary characters
# Output:       String of equivalent hex value.
# Description:  Convert binary to hex.
sub subBinToHex
{
  my $bin = shift(@_);
  $hex  = "";
  while (length($bin)%4)
  {
    $bin  = "0" . $bin;
  }
  while (length($bin))
  {
    $hex  .= $hexval{substr($bin,0,4)};
    $bin  = substr($bin,4);
  }
  return $hex;
}


##############################################################################
# sub:          subTwosComplementChecksumOfHexStringOfBytes
# Input:        String of hexadecimal characters
# Output:       8-bit 2's-complement checksum
# Description:  Calculate the 8-bit, 2's-complement checksum from the given
#               string of hexadecimal characters as bytes (hex-char-pairs).
sub subTwosComplementChecksumOfHexStringOfBytes($)
{
  my $hexString = shift(@_);

  # Check for valid hex chars
  if ($hexString !~ /^[0-9A-Fa-f]+$/)
  {
    die "ERROR:  Invalid hex string:  $hexString\n";
  }

  # Check for hexadecimal character pairs for bytes
  my $hexStringLength = length($hexString);
  my $bytes           = $hexStringLength / 2;
  if ($hexStringLength % 2)
  {
    die "ERROR:  Invalid number of hex chars for hex-pair byte values\n";
  }

  # Compute checksum
  $checksum = 0;
  for ($i=0;$i<$bytes;$i++)
  {
    my $hexByte = substr($hexString,(2*$i),2);
    $checksum += hex($hexByte);
  }

  # Compute 8-bit two's complement
  $checksum = (($checksum ^ 0xFF) + 1) & 0xFF;

  return($checksum);
}

##############################################################################
# sub:          subBinRead
# Input:        $binFileName      = Input path\file name
# Output:       String of bytes as hex char pairs.
# Description:  Subroutine to read a pure binary file.
sub subBinRead
{
  my $binFileName = shift(@_);

  my $hexData     = "";

  if (!open(BINFILEREAD, "<$binFileName"))
  {
    print "ERROR:  Cannot open bin file:  $binFileName\n";
    die;
  }
  else
  {
    binmode(BINFILEREAD);
    print "INFO:  Reading BIN file:  $binFileName...\n";
  }


  while (!eof(BINFILEREAD))
  {
    $binByte  = getc(BINFILEREAD);
    $hexByte  = sprintf("%02X", ord($binByte));
    $hexData .= $hexByte;
  }
  close(BINFILEREAD);

  $hexDataLength  = length($hexData) / 2;

  printf("INFO:  Read BIN:   Data Start Address = %09d (0x%08X)\n",0,0);
  printf("INFO:  Read BIN:   Data End Address   = %09d (0x%08X)\n",($hexDataLength-1),($hexDataLength-1));
  printf("INFO:  Read BIN:   Data Length        = %09d (0x%08X)\n",$hexDataLength,$hexDataLength);

  return($hexData);
}


##############################################################################
# sub:          subHexRead
# Input:        $hexFileName      = Input path\file name
# Output:       String of bytes as hex char pairs.
# Description:  Subroutine to read an ASCII hex-pair stream of bytes.
#               Whitespace is ignored.
sub subHexRead
{
  my $hexFileName = shift(@_);

  my $hexData     = "";
  my $lineNumber  = 0;

  if (!open(HEXFILEREAD, "<$hexFileName"))
  {
    print "ERROR:  Cannot open hex file:  $hexFileName\n";
    die;
  }
  else
  {
    print "INFO:  Reading HEX file:  $hexFileName...\n";
  }

  while (<HEXFILEREAD>)
  {
    $lineNumber++;
    my $line        = "";
    my $inputLineLen= length($_);

    # Strip whitespace
    for (my $i=0;$i<$inputLineLen;$i++)
    {
      my $char  = substr($_,$i,1);
      if ($char =~ /[0-9A-Fa-f]/)
      {
        $line .= $char;
      }
      elsif ($char =~ /\S/)
      {
        die "ERROR:  Non-hex char ($char) on line number $lineNumber\n";
      }
    }
    my $lineLength  = length($line);

    if ($lineLength % 2)
    {
      print "WARNING:  Number of hex characters is not a multiple of 2 on line number $lineNumber\n";
    }

    $hexData  .= $line;
  }
  close(HEXFILEREAD);

  if (length($hexData) % 2)
  {
    die "ERROR:  Number of hex characters is not a multiple of 2 (Note: 2 chars/byte)\n";
  }


  $hexDataLength  = length($hexData) / 2;

  printf("INFO:  Read HEX:   Data Start Address = %09d (0x%08X)\n",0,0);
  printf("INFO:  Read HEX:   Data End Address   = %09d (0x%08X)\n",($hexDataLength-1),($hexDataLength-1));
  printf("INFO:  Read HEX:   Data Length        = %09d (0x%08X)\n",$hexDataLength,$hexDataLength);

  return($hexData);
}


##############################################################################
# sub:          subMcsRead
# Input:        $mcsFileName      = Input .MCS path\file name
#               $mcsFill          = [Optional] Byte value (2-char hex pair)
#                                   to fill gaps.
#               $mcsFillFromZero  = [Optional] Byte value (2-char hex pair)
#                                   to fill a gap from address zero.
# Output:       String of bytes as hex char pairs.  If a gap is not filled,
#               a "XX<ADDR>" string can be found in the return value where
#               <ADDR> is a 32-bit (8-char) hex value that represents the byte
#               address for the first byte of data in the next set.
# Description:  Subroutine to read a .MCS file.
sub subMcsRead
{
  my $mcsFileName           = shift(@_);
  my $mcsFill               = shift(@_);
  my $mcsFillFromZero       = shift(@_);

  my $mcsDataHex            = "";
  my $mcsDataAddressStart   = -1;
  my $mcsDataAddressCurrent = 0;
  my $mcsGaps               = 0;
  my $mcsSegmentAddress     = 0;
  my $mcsStartSegmentAddress= "";
  my $mcsStartLinearAddress = "";
  my $lineNumber            = 0;
  my $eof                   = 0;

  if (!open(MCSFILEREAD, "<$mcsFileName"))
  {
    print "ERROR:  Cannot open .MCS file:  $mcsFileName\n";
    die;
  }
  else
  {
    print "INFO:  Reading MCS file:  $mcsFileName...\n";
  }

  while (<MCSFILEREAD>)
  {
    $lineNumber++;
    my $errorMsg    = "";
    my $warningMsg  = "";

    # Strip trailing whitespace
    while ($_ =~ /\s$/)
    {
      chomp;
    }
    my $lineLength  = length($_);

    # Check for a valid record
    if ($_ =~ /^\s*$/)
    {
      if (!$eof)
      {
        $warningMsg .= "WARNING:  Found empty line.\n";
      }
    }
    elsif ($eof)
    {
      $warningMsg .= "WARNING:  Extra information after end of file record\n";
    }
    elsif ($_ !~ /^\:/)
    {
      $errorMsg = sprintf("ERROR:  Expected line to begin with Record Mark ':', but found: '%s'\n", substr($_,0,1));
    }
    elsif ($lineLength < 11)
    {
      $errorMsg = "ERROR:  Insufficient characters ($lineLength) on line for a valid record\n";
    }
    elsif ($_ =~ /^\:([0-9A-Fa-f]{2})([0-9A-Fa-f]{4})([0-9A-Fa-f]{2})([0-9A-Fa-f]*)([0-9A-Fa-f]{2})$/)
    {
      my $mcsLineRecLenHex      = $1;
      my $mcsLineRecLen         = hex($mcsLineRecLenHex);
      my $mcsLineLoadOffsetHex  = $2;
      my $mcsLineLoadOffset     = hex($mcsLineLoadOffsetHex);
      my $mcsLineRecTypHex      = $3;
      my $mcsLineDataHex        = $4;
      my $mcsLineDataLength     = length($mcsLineDataHex);
      my $mcsLineDataBytes      = $mcsLineDataLength / 2;
      my $mcsLineChksumHex      = $5;
      my $mcsLineChksum         = hex($mcsLineChksumHex);
      my $mcsLineCalcChksum     = subTwosComplementChecksumOfHexStringOfBytes(substr($_,1,($lineLength-3)));
      my $mcsLineCalcChksumHex  = sprintf("%02X",$mcsLineCalcChksum);

      if ($mcsLineDataLength % 2)
      {
        $errorMsg = "ERROR:  Number of hex data characters is not a multiple of 2 (2 chars/byte)\n";
      }
      elsif ($mcsLineRecLen != $mcsLineDataBytes)
      {
        $errorMsg = "ERROR:  Record Length = $mcsLineRecLen, but actual data bytes count = $mcsLineDataBytes\n";
      }
      elsif ($mcsLineRecTypHex eq "00")
      {
        if ($mcsLineCalcChksum ne $mcsLineChksum)
        {
          $warningMsg .= "WARNING:  Checksum error.  Expected \"$mcsLineCalcChksumHex\", but found \"$mcsLineChksumHex\"\n";
        }

        # Data record
        if ($mcsLineRecLen)
        {
          # Check for gaps and fill as specified
          $mcsLineByteAddress = $mcsSegmentAddress + $mcsLineLoadOffset;
          if ($mcsDataHex eq "")
          {
            if ($mcsFillFromZero ne "")
            {
              while ($mcsDataAddressCurrent < $mcsLineByteAddress)
              {
                $mcsDataHex .= $mcsFillFromZero;
                $mcsDataAddressCurrent++;
              }
              if ($mcsDataAddressStart == -1) {$mcsDataAddressStart=0;}
            }
            elsif ($mcsDataAddressCurrent < $mcsLineByteAddress)
            {
              #$warningMsg .= sprintf("WARNING:  Gap from 0x%08X to 0x%08X\n",
              #                       $mcsDataAddressCurrent, $mcsLineByteAddress);
              $mcsGaps++;
              $mcsDataHex .= "XX"; # Gap;  Mark new address with "XX"
              $mcsDataHex .= sprintf("%08X",$mcsLineByteAddress);
              $mcsDataAddressCurrent  = $mcsLineByteAddress;
              if ($mcsDataAddressStart == -1) {$mcsDataAddressStart=$mcsDataAddressCurrent;}
            }
            elsif ($mcsDataAddressStart == -1)
            {
              $mcsDataAddressStart=$mcsDataAddressCurrent;
            }
          }
          elsif ($mcsFill ne "")
          {
            while ($mcsDataAddressCurrent < $mcsLineByteAddress)
            {
              $mcsDataHex .= $mcsFill;
              $mcsDataAddressCurrent++;
            }
          }
          elsif ($mcsDataAddressCurrent < $mcsLineByteAddress)
          {
            #$warningMsg .= sprintf("WARNING:  Gap from 0x%08X to 0x%08X\n",
            #                       $mcsDataAddressCurrent, $mcsLineByteAddress);
            $mcsGaps++;
            $mcsDataHex .= "XX"; # Gap;  Mark new address with "XX"
            $mcsDataHex .= sprintf("%08X",$mcsLineByteAddress);
            $mcsDataAddressCurrent  = $mcsLineByteAddress;
          }

          # Place the data from the line
          $mcsDataHex .= $mcsLineDataHex;
          $mcsDataAddressCurrent  += $mcsLineDataBytes;
        }
      }
      elsif ($mcsLineRecTypHex eq "01")
      {
        if ($mcsLineCalcChksum ne $mcsLineChksum)
        {
          $warningMsg .= "WARNING:  Checksum error.  Expected \"$mcsLineCalcChksumHex\", but found \"$mcsLineChksumHex\"\n";
        }
        # End of file record
        if ($mcsLineRecLenHex ne "00")
        {
          $warningMsg .= "WARNING:  Expected \"00\" for record length, but found \"$mcsLineRecLenHex\"\n";
        }
        if ($mcsLineLoadOffsetHex ne "0000")
        {
          $warningMsg .= "WARNING:  Expected \"0000\" for load offset, but found \"$mcsLineLoadOffsetHex\"\n";
        }
        $eof  = 1;
      }
      elsif ($mcsLineRecTypHex eq "02")
      {
        if ($mcsLineCalcChksum ne $mcsLineChksum)
        {
          $warningMsg .= "WARNING:  Checksum error.  Expected \"$mcsLineCalcChksumHex\", but found \"$mcsLineChksumHex\"\n";
        }
        # Extended segment address record
        if ($mcsLineRecLenHex ne "02")
        {
          $errorMsg = "ERROR:  Expected \"02\" for record length, but found \"$mcsLineRecLenHex\"\n";
        }
        else
        {
          if ($mcsLineLoadOffsetHex ne "0000")
          {
            $warningMsg .= "WARNING:  Expected \"0000\" for load offset, but found \"$mcsLineLoadOffsetHex\"\n";
          }
          $mcsSegmentAddressHex = $mcsLineDataHex . "0";
          $mcsSegmentAddress    = hex($mcsSegmentAddressHex);
          if ($mcsSegmentAddress < $mcsDataAddressCurrent)
          {
            $errorMsg = "ERROR:  Extended segment address record is not sequential\n";
          }
        }
      }
      elsif ($mcsLineRecTypHex eq "03")
      {
        if ($mcsLineCalcChksum ne $mcsLineChksum)
        {
          $warningMsg .= "WARNING:  Checksum error.  Expected \"$mcsLineCalcChksumHex\", but found \"$mcsLineChksumHex\"\n";
        }
        # Start segment address record
        if ($mcsLineRecLenHex ne "04")
        {
          $errorMsg = "ERROR:  Expected \"04\" for record length, but found \"$mcsLineRecLenHex\"\n";
        }
        else
        {
          if ($mcsLineLoadOffsetHex ne "0000")
          {
            $warningMsg .= "WARNING:  Expected \"0000\" for load offset, but found \"$mcsLineLoadOffsetHex\"\n";
          }
          if (length($mcsLineStartSegmentAddress))
          {
            $warningMsg .= "WARNING:  Found more than one start segment address record.\n";
          }
          $mcsLineStartSegmentAddress = $mcsLineDataHex;
          $warningMsg .= "WARNING:  Ignoring start segment address ($mcsLineStartSegmentAddress) record.\n";
        }
      }
      elsif ($mcsLineRecTypHex eq "04")
      {
        if ($mcsLineCalcChksum ne $mcsLineChksum)
        {
          $warningMsg .= "WARNING:  Checksum error.  Expected \"$mcsLineCalcChksumHex\", but found \"$mcsLineChksumHex\"\n";
        }
        # Extended linear address record
        if ($mcsLineRecLenHex ne "02")
        {
          $errorMsg = "ERROR:  Expected \"02\" for record length, but found \"$mcsLineRecLenHex\"\n";
        }
        else
        {
          if ($mcsLineLoadOffsetHex ne "0000")
          {
            $warningMsg .= "WARNING:  Expected \"0000\" for load offset, but found \"$mcsLineLoadOffsetHex\"\n";
          }
          $mcsSegmentAddressHex = $mcsLineDataHex . "0000";
          $mcsSegmentAddress    = hex($mcsSegmentAddressHex);
          if ($mcsSegmentAddress < $mcsDataAddressCurrent)
          {
            $errorMsg = "ERROR:  Extended linear address record is not sequential\n";
          }
        }
      }
      elsif ($mcsLineRecTypHex eq "05")
      {
        if ($mcsLineCalcChksum ne $mcsLineChksum)
        {
          $warningMsg .= "WARNING:  Checksum error.  Expected \"$mcsLineCalcChksumHex\", but found \"$mcsLineChksumHex\"\n";
        }
        # Start linear address record
        if ($mcsLineRecLenHex ne "04")
        {
          $errorMsg .= "WARNING:  Expected \"04\" for record length, but found \"$mcsLineRecLenHex\"\n";
        }
        else
        {
          if ($mcsLineLoadOffsetHex ne "0000")
          {
            $warningMsg .= "WARNING:  Expected \"0000\" for load offset, but found \"$mcsLineLoadOffsetHex\"\n";
          }
          if (length($mcsLineStartLinearAddress))
          {
            $warningMsg .= "WARNING:  Found more than one start linear address record.\n";
          }
          $mcsLineStartLinearAddress  = $mcsLineDataHex;
          $warningMsg .= "WARNING:  Ignoring start linear address ($mcsLineStartLinearAddress) record.\n";
        }
      }
      else
      {
        $errorMsg = "ERROR:  Unrecognized record type '$mcsLineRecTypHex'\n";
      }
    }
    else
    {
      $errorMsg = "ERROR:  Invalid (non-hexadecimal) characters on line\n";
    }

    if (length($errorMsg)||length($warningMsg))
    {
      print "$warningMsg$errorMsg";
      print "  LINE[$lineNumber]: \"$_\"\n";
      if (length($errorMsg))
      {
        die;
      }
    }
  }
  close(MCSFILEREAD);

  my $mcsDataLength     = $mcsDataAddressCurrent - $mcsDataAddressStart;
  my $mcsDataAddressEnd = $mcsDataAddressCurrent - 1;
  printf("INFO:  Read MCS:   Data Start Address = %09d (0x%08X)\n",$mcsDataAddressStart,$mcsDataAddressStart);
  printf("INFO:  Read MCS:   Data End Address   = %09d (0x%08X)\n",$mcsDataAddressEnd,$mcsDataAddressEnd);
  printf("INFO:  Read MCS:   Data Length        = %09d (0x%08X)\n",$mcsDataLength,$mcsDataLength);

  return($mcsDataHex);
}


##############################################################################
# sub:          subGenerateRuntest
# Input:        $tckCount       = TCK cycles for RUNTEST/WAIT.
#               $optMaxRuntest  = max count per runtest/wait;
# Output:       String of RUNTEST/WAIT statement(s).
# Description:
sub subGenerateRuntest
{
  my $tckCount      = shift(@_);
  my $optMaxRuntest = shift(@_);
  my $prefix        = shift(@_);
  my $runtest       = "";

  if ($optMaxRuntest > 0)
  {
    while ($tckCount > $optMaxRuntest)
    {
      $runtest  .= $prefix;
      $runtest  .= "WAIT $optMaxRuntest CYCLES;\n";
      $tckCount -=  $optMaxRuntest;
    }
  }

  if ($tckCount > 0)
  {
    $runtest  .= $prefix;
    $runtest  .= "WAIT $tckCount CYCLES;";
  }

  return($runtest);
}


##############################################################################
# Main
##############################################################################

my  $optHir     = 0;
my  $optTir     = 0;
my  $optHdr     = 0;
my  $optTdr     = 0;
my  $optDevice  = "P30";
my  $optLoadFpga= 0;
my  $optMaxRuntest= 5000;
my  $optCheckStatus=0;
my  $optCheckSyncword=1;
my  $optTckFreqMHz= 6;

##############################################################################
# Process command-line arguments

##### No arguments or -h, then print the help
if ((@ARGV==0) || (lc($ARGV[0]) eq "-h"))
{
  PrintHelp();
}

##### Process command-line switches
while ($ARGV[0] =~ /^-/)
{
  if (lc($ARGV[0]) =~ /^-tckfreq/)
  {
    shift;
    $optTckFreqMHz = $ARGV[0];
    print("INFO:  -tckfreq set to: $optTckFreqMHz\n");
  }
  elsif (lc($ARGV[0]) =~ /^-hir/)
  {
    shift;
    $optHir = $ARGV[0];
    print("INFO:  -hir set to: $optHir\n");
  }
  elsif (lc($ARGV[0]) =~ /^-tir/)
  {
    shift;
    $optTir = $ARGV[0];
    print("INFO:  -tir set to: $optTir\n");
  }
  elsif (lc($ARGV[0]) =~ /^-hdr/)
  {
    shift;
    $optHdr = $ARGV[0];
    print("INFO:  -hdr set to: $optHdr\n");
  }
  elsif (lc($ARGV[0]) =~ /^-tdr/)
  {
    shift;
    $optTdr = $ARGV[0];
    print("INFO:  -tdr set to: $optTdr\n");
  }
  elsif (lc($ARGV[0]) =~ /^-loadfpga/)
  {
    $optLoadFpga = 1;
    print("INFO:  -loadfpga = Reload FPGA after programming update image.\n");
  }
  elsif (lc($ARGV[0]) =~ /^-nosyncword/)
  {
    $optCheckSyncword = 0;
    print("INFO:  -nosyncword = Do not check syncword erase/program flags.\n");
  }
  elsif (lc($ARGV[0]) =~ /^-maxruntest/)
  {
    shift;
    $optMaxRuntest = $ARGV[0];
    print("INFO:  -maxruntest set to: $optMaxRuntest\n");
  }
  elsif (lc($ARGV[0]) =~ /^-checkstatus/)
  {
    $optCheckStatus = 1;
    print("INFO:  -checkstatus = for debug, insert TDO checks for ready status.\n");
  }
  elsif (lc($ARGV[0]) =~ /^-device/)
  {
    shift;
    $optDevice = uc($ARGV[0]);
    if ($optDevice eq "P30")
    {
      print("INFO:  -device P30 = Micron P30 device.\n");
    }
    elsif ($optDevice eq "G18")
    {
      print("INFO:  -device G18 = adjust for Micron G18 device.\n");
    }
    else
    {
      print("WARNING:  Did not recognize -device $optDevice.  Ignoring.\n");
      $optDevice  = "P30";
    }
  }
  else
  {
    print("WARNING:  Did not recognize command-line option: $ARGV[0]\n");
  }
  shift;
}

$cClkFrequencyHz= int($optTckFreqMHz * 1000000);
$timeOutErase   = int($cClkFrequencyHz * $cTimeOutErase);
$timeOutProgram = int($cClkFrequencyHz * $cTimeOutProgram);

if ($optDevice eq "P30")
{
  $cSizeBlock = $cSizeBlockP30;
}
elsif ($optDevice eq "G18")
{
  $cSizeBlock = $cSizeBlockG18;
}

my  $fileNameMcsInput   = $ARGV[0];
print("INFO:  Input MCS file name set to: $fileNameMcsInput\n");
my  $fileNameType       = substr($fileNameMcsInput,-4,4);
if (lc($fileNameType) ne ".mcs")
{
  die "ERROR: Input file $fileNameMcsInput is not a .mcs file\n";
}
my  $fileNameRoot       = substr($fileNameMcsInput,0,-4);
if (length($fileNameRoot) == 0)
{
  die "ERROR: Invalid input file $fileNameMcsInput\n";
}
my  $fileNameStapl  = $fileNameRoot . ".stapl";
my  $fileNameCheckIdStapl = $fileNameRoot . "_checkid.stapl";
my  $fileNameVerifyStapl = $fileNameRoot . "_verify.stapl";

print "INFO:  TCK Frequency                   = $cClkFrequencyHz Hz\n";
print "INFO:  HIR                             = $optHir bits\n";
print "INFO:  TIR                             = $optTir bits\n";
print "INFO:  HDR                             = $optHdr bits\n";
print "INFO:  TDR                             = $optTdr bits\n";
print "INFO:  Max RUNTEST                     = $optMaxRuntest TCK cycles\n";
print "INFO:  Device                          = $optDevice\n";
print "INFO:  Input MCS file name             = $fileNameMcsInput\n";
print "INFO:  Output STAPL file name          = $fileNameStapl\n";
print "INFO:  Output check ID STAPL file name = $fileNameCheckIdStapl\n";
print "INFO:  Output verify STAPL file name   = $fileNameVerifyStapl\n";

# Setup HIR/TIR/HDR/TDR
if (($optHir==0)&&($optTir==0)&&($optHdr==0)&&($optTdr==0))
{
  $HirTirHdrTdr = "'---------------------------------------------------------\n"
                . "'If other devices in scan chain, set PREIR/POSTIR/PREDR/POSTDR below\n"
                . "'PREIR N, #11111111; ' Set N length and TDI to all ones\n"
                . "'POSTIR M, #11111111; ' Set M length and TDI to all ones\n"
                . "'PREDR X, #00; ' Set X length and TDI to all zeros\n"
                . "'POSTDR Y, #00; ' Set Y length and TDI to all zeros\n"
                . "'---------------------------------------------------------"
}
else
{
  $HirTirHdrTdr = "";
  if ($optHir=0)
  {
    $HirTirHdrTdr .= "PREIR 0;\n";
  }
  else
  {
    $ones = "";
    for ($i=0;$i<$optHir;$i++)
    {
      $ones = $ones . "1";
    }
    $HirTirHdrTdr .= "PREIR $optHir,#" . $ones . ";\n";
  }
  if ($optTir=0)
  {
    $HirTirHdrTdr .= "POSTIR 0;\n";
  }
  else
  {
    $ones = "";
    for ($i=0;$i<$optTir;$i++)
    {
      $ones = $ones . "1";
    }
    $HirTirHdrTdr .= "POSTIR $optTir, #" . $ones . ";\n";
  }
  if ($optHdr=0)
  {
    $HirTirHdrTdr .= "PREDR 0;\n";
  }
  else
  {
    $zeros = "";
    for ($i=0;$i<$optHdr;$i++)
    {
      $zeros = $zeros . "0";
    }
    $HirTirHdrTdr .= "PREDR $optHdr, #$zeros;\n";
  }
  if ($optTdr=0)
  {
    $HirTirHdrTdr .= "POSTDR 0;\n";
  }
  else
  {
    $zeros = "";
    for ($i=0;$i<$optTdr;$i++)
    {
      $zeros = $zeros . "0";
    }
    $HirTirHdrTdr .= "POSTDR $optTdr, #$zeros;\n";
  }
}

my $mcsDataHex = subMcsRead($fileNameMcsInput);
my $mcsDataStartAddr    = 0;
my $mcsDataStartAddrHex = "00000000";
if (substr($mcsDataHex,0,2) eq "XX")
{
  $mcsDataStartAddrHex  = substr($mcsDataHex,2,8);
  $mcsDataStartAddr     = hex($mcsDataStartAddrHex);
  $mcsDataHex           = substr($mcsDataHex,10);
}
if (index($mcsDataHex,"XX")>=0)
{
  die "ERROR:  Input MCS data has unexpected gaps in defined data.\n";
}
my $mcsDataLength = length($mcsDataHex) / 2;
if ($mcsDataLength==0)
{
  die "ERROR:  Input MCS has no data\n";
}
my $numBlocks = $mcsDataLength / 2 / $cSizeBlock;
if ($mcsDataLength != (2*($numBlocks * $cSizeBlock)))
{
  die "ERROR:  Input MCS data length is not a multiple of the flash block size.";
}
my $numBuffers    = $mcsDataLength / 2 / $cSizeBuffer;
print "INFO:  Number of blocks  = $numBlocks\n";
print "INFO:  Number of buffers = $numBuffers\n";

# Prepare to write STAPL file
if (!open(STAPLFILE, ">$fileNameStapl"))
{
  print "ERROR:  Cannot open .STAPL file:  $fileNameStapl\n";
  die;
}
else
{
  print "INFO:  Writing STAPL file:  $fileNameStapl\n";

  if ($optCheckSyncword == 1)
  {
    $tdoMask = "0007FFFF";
  }
  else
  {
    $tdoMask = "0003BFFF";
  }

  print STAPLFILE "NOTE \"CREATOR\" \"MakeBpiFlashProgrammerStaplFiles.pl\";\n";
  print STAPLFILE "NOTE \"DEVICE\" \"7 Series\";\n";
  ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime(time);
  $year += 1900;
  $mon  += 1;
  print STAPLFILE "NOTE \"DATE\" \"$year/$mon/$mday\";\n";
  print STAPLFILE "NOTE \"STAPL_VERSION\" \"JEDS00-A\";\n";
  print STAPLFILE "NOTE \"ALG_VERSION\" \"3\";\n";
  print STAPLFILE "NOTE \"STACK_DEPTH\" \"2\";\n";
  print STAPLFILE "NOTE \"MAX_FREQ\" \"$cClkFrequencyHz\";\n";
  print STAPLFILE "NOTE \"TARGET\" \"1\";\n";
  print STAPLFILE "ACTION PROGRAM = DO_PROGRAM;\n";
  print STAPLFILE "PROCEDURE DO_PROGRAM;\n";
  print STAPLFILE "'Declare variables for data arrays\n";
  print STAPLFILE "BOOLEAN RESULT;\n";
  print STAPLFILE "INTEGER I;\n";
  print STAPLFILE "$HirTirHdrTdr\n";
  print STAPLFILE "STATE RESET;\n";
  print STAPLFILE "IRSTOP IDLE;\n";
  print STAPLFILE "DRSTOP IDLE;\n";
  print STAPLFILE "' Load USER1 instruction to access the BpiFlashProgrammer\n";
  print STAPLFILE "IRSCAN $cJtagIRLength, #$cJtagUser1;\n";
  print STAPLFILE "' Activate programmer.\n";
  print STAPLFILE "DRSCAN 32, \$0000CA75;\n";
  print STAPLFILE "' Wait to initialize and read ID\n";
  $tckMax = 16;
  printf(STAPLFILE "%s\n", subGenerateRuntest($tckMax,$optMaxRuntest,""));
  print STAPLFILE "' Check ID OK\n";
  print STAPLFILE "DRSCAN 32, \$00000000, COMPARE \$00003800, \$$tdoMask, RESULT;\n";
  if ($optCheckSyncword==1)
  {
    print STAPLFILE "' Wait to corrupt sync word\n";
    $tckMax += 16;               # Send block erase to corrupt sync word
    $tckMax += $timeOutErase;   # Wait for block erase to corrupt sync word
  }
  $tckMax += ($numBlocks * (16 + $timeOutErase));
  $tckMax += 32;               # Send first buffer program
  print STAPLFILE "' Load data for buffer programming\n";
  $tckMaxStep = int(($tckMax+15) / 16);
  $nextWord = substr($mcsDataHex,0,8);
  print STAPLFILE "FOR I = 1 TO 16 STEP 1;\n";
  printf(STAPLFILE "%s\n", subGenerateRuntest($tckMaxStep, $optMaxRuntest, "  "));;
  print STAPLFILE "  DRSCAN 32, \$$nextWord, COMPARE \$0000F801, \$$tdoMask, RESULT;\n";
  print STAPLFILE "  IF RESULT==1 THEN I=16;\n";
  print STAPLFILE "NEXT I;\n";
  print STAPLFILE "IF RESULT==0 THEN EXIT 8;\n";
  $tckMax = $timeOutProgram + 32; # Wait buffer program max + send next buffer program command
  $tckMaxStep = int(($tckMax + 15)/ 16);
  for ($i=4;$i<$mcsDataLength;$i=$i+4)
  {
    $nextWord   = substr($mcsDataHex,($i*2),8);
    if (($i%$cSizeBuffer)==0)
    {
      print STAPLFILE "FOR I = 1 TO 16 STEP 1;\n";
      printf(STAPLFILE "%s\n", subGenerateRuntest($tckMaxStep, $optMaxRuntest, "  "));;
      print STAPLFILE "  DRSCAN 32, \$$nextWord, COMPARE \$0000F801, \$$tdoMask, RESULT;\n";
      print STAPLFILE "  IF RESULT==1 THEN I=16;\n";
      print STAPLFILE "NEXT I;\n";
      print STAPLFILE "IF RESULT==0 THEN EXIT 10;\n";
    }
    else
    {
      print STAPLFILE "WAIT 9 CYCLES;\n";
      print STAPLFILE "DRSCAN 32, \$$nextWord";
      if ($optCheckStatus==1)
      {
        print STAPLFILE ", COMPARE \$0000F801, \$$tdoMask, RESULT;\n";
        print STAPLFILE "IF RESULT==0 THEN EXIT 20;\n";
      }
      else
      {
        print STAPLFILE ";\n";
      }
    }
  }

  print STAPLFILE "' Wait to program last buffer\n";
  print STAPLFILE "FOR I = 1 TO 16 STEP 1;\n";
  printf(STAPLFILE "%s\n", subGenerateRuntest($tckMaxStep, $optMaxRuntest, "  "));;
  print STAPLFILE "  DRSCAN 32, \$$nextWord, COMPARE \$0001F800, \$$tdoMask, RESULT;\n";
  print STAPLFILE "  IF RESULT==1 THEN I=16;\n";
  print STAPLFILE "NEXT I;\n";
  print STAPLFILE "IF RESULT==0 THEN EXIT 10;\n";

  print STAPLFILE "' Verify via CRC check\n";
  $tckMax = 32; # Send READ + address + extra margin
  $tckMax += $mcsDataLength;
  if ($optCheckSyncword==1)
  {
    $tckMax += 32 + $timeOutProgram; # Add syncword program time
  }
  printf(STAPLFILE "%s\n", subGenerateRuntest($tckMax, $optMaxRuntest, ""));;

  print STAPLFILE "' Check DONE\n";
  print STAPLFILE "DRSCAN 32, \$00000000, COMPARE \$0007F803, \$$tdoMask, RESULT;\n";
  print STAPLFILE "IF RESULT==0 THEN EXIT 11;\n";
  if ($optLoadFpga == 1)
  {
    print STAPLFILE "' Reload FPGA\n";
    print STAPLFILE "IRSCAN $cJtagIRLength, #$cJtagJProgram;\n";
  }
  print STAPLFILE "STATE RESET;\n";
  print STAPLFILE "EXIT 0;\n";
  print STAPLFILE "ENDPROC;\n";
  close(STAPLFILE);
}

# Prepare to write verify only STAPL file
if (!open(VERIFYSTAPLFILE, ">$fileNameVerifyStapl"))
{
  print "ERROR:  Cannot open .STAPL file:  $fileNameVerifyStapl\n";
  die;
}
else
{
  print "INFO:  Writing verify-only STAPL file:  $fileNameVerifyStapl\n";

  print VERIFYSTAPLFILE "NOTE \"CREATOR\" \"MakeBpiFlashProgrammerVERIFYSTAPLFILEs.pl\";\n";
  print VERIFYSTAPLFILE "NOTE \"DEVICE\" \"7 Series\";\n";
  ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime(time);
  $year += 1900;
  $mon  += 1;
  print VERIFYSTAPLFILE "NOTE \"DATE\" \"$year/$mon/$mday\";\n";
  print VERIFYSTAPLFILE "NOTE \"STAPL_VERSION\" \"JEDS00-A\";\n";
  print VERIFYSTAPLFILE "NOTE \"ALG_VERSION\" \"3\";\n";
  print VERIFYSTAPLFILE "NOTE \"STACK_DEPTH\" \"2\";\n";
  print VERIFYSTAPLFILE "NOTE \"MAX_FREQ\" \"$cClkFrequencyHz\";\n";
  print VERIFYSTAPLFILE "NOTE \"TARGET\" \"1\";\n";
  print VERIFYSTAPLFILE "ACTION PROGRAM = DO_VERIFY;\n";
  print VERIFYSTAPLFILE "PROCEDURE DO_VERIFY;\n";
  print VERIFYSTAPLFILE "'Declare variables for data arrays\n";
  print VERIFYSTAPLFILE "BOOLEAN RESULT;\n";
  print VERIFYSTAPLFILE "INTEGER I;\n";
  print VERIFYSTAPLFILE "$HirTirHdrTdr\n";
  print VERIFYSTAPLFILE "STATE RESET;\n";
  print VERIFYSTAPLFILE "IRSTOP IDLE;\n";
  print VERIFYSTAPLFILE "DRSTOP IDLE;\n";
  print VERIFYSTAPLFILE "' Load USER1 instruction to access the BpiFlashProgrammer\n";
  print VERIFYSTAPLFILE "IRSCAN $cJtagIRLength, #$cJtagUser1;\n";
  print VERIFYSTAPLFILE "' Activate programmer verify only option.\n";
  print VERIFYSTAPLFILE "DRSCAN 32, \$00001423;\n";
  print VERIFYSTAPLFILE "' Wait to initialize and read ID\n";
  print VERIFYSTAPLFILE "WAIT 80 CYCLES;\n";
  print VERIFYSTAPLFILE "' Check no ID error\n";
  print VERIFYSTAPLFILE "DRSCAN 32, \$00000000, COMPARE \$00003800, \$$tdoMask, RESULT;\n";
  print VERIFYSTAPLFILE "IF RESULT==0 THEN EXIT 2;\n";
  print VERIFYSTAPLFILE "' Verify via CRC check\n";
  $tckMax = 16; # Send READ + address + extra margin
  $tckMax = $tckMax + $mcsDataLength;
  printf(VERIFYSTAPLFILE "%s\n", subGenerateRuntest($tckMax, $optMaxRuntest, ""));;

  print VERIFYSTAPLFILE "' Check DONE\n";
  print VERIFYSTAPLFILE "DRSCAN 32, \$00000000, COMPARE \$00023803, \$$tdoMask, RESULT;\n";
  print VERIFYSTAPLFILE "IF RESULT==0 THEN EXIT 11;\n";
  print VERIFYSTAPLFILE "STATE RESET;\n";
  print VERIFYSTAPLFILE "EXIT 0;\n";
  print VERIFYSTAPLFILE "ENDPROC;\n";
  close(VERIFYSTAPLFILE);
}

# Prepare to write check ID STAPL file
if (!open(CHECKIDSTAPLFILE, ">$fileNameCheckIdStapl"))
{
  print "ERROR:  Cannot open .STAPL file:  $fileNameCheckIdStapl\n";
  die;
}
else
{
  print "INFO:  Writing STAPL file:  $fileNameCheckIdStapl\n";

  print CHECKIDSTAPLFILE "NOTE \"CREATOR\" \"MakeBpiFlashProgrammerStaplFiles.pl\";\n";
  print CHECKIDSTAPLFILE "NOTE \"DEVICE\" \"7 Series\";\n";
  ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime(time);
  $year += 1900;
  $mon  += 1;
  print CHECKIDSTAPLFILE "NOTE \"DATE\" \"$year/$mon/$mday\";\n";
  print CHECKIDSTAPLFILE "NOTE \"STAPL_VERSION\" \"JEDS00-A\";\n";
  print CHECKIDSTAPLFILE "NOTE \"ALG_VERSION\" \"3\";\n";
  print CHECKIDSTAPLFILE "NOTE \"STACK_DEPTH\" \"2\";\n";
  print CHECKIDSTAPLFILE "NOTE \"MAX_FREQ\" \"$cClkFrequencyHz\";\n";
  print CHECKIDSTAPLFILE "NOTE \"TARGET\" \"1\";\n";
  print CHECKIDSTAPLFILE "ACTION PROGRAM = DO_CHECK_IDCODE;\n";
  print CHECKIDSTAPLFILE "PROCEDURE DO_CHECK_IDCODE;\n";
  print CHECKIDSTAPLFILE "'Declare variables for data arrays\n";
  print CHECKIDSTAPLFILE "BOOLEAN RESULT;\n";
  print CHECKIDSTAPLFILE "$HirTirHdrTdr\n";
  print CHECKIDSTAPLFILE "STATE RESET;\n";
  print CHECKIDSTAPLFILE "IRSTOP IDLE;\n";
  print CHECKIDSTAPLFILE "DRSTOP IDLE;\n";
  print CHECKIDSTAPLFILE "' Load USER1 instruction to access the BpiFlashProgrammer\n";
  print CHECKIDSTAPLFILE "IRSCAN $cJtagIRLength, #$cJtagUser1;\n";
  print CHECKIDSTAPLFILE "' Activate check-ID-only.\n";
  print CHECKIDSTAPLFILE "DRSCAN 32, \$00001DCD;\n";
  print CHECKIDSTAPLFILE "' Wait to initialize and read IDCODE\n";
  print CHECKIDSTAPLFILE "WAIT 16 CYCLES;\n";
  print CHECKIDSTAPLFILE "' Check for DONE with no error flags\n";
  print CHECKIDSTAPLFILE "DRSCAN 32, \$00000000, COMPARE \$00003803, \$0007FFFF, RESULT;\n";
  print CHECKIDSTAPLFILE "IF RESULT==0 THEN EXIT 2;\n";
  print CHECKIDSTAPLFILE "STATE RESET;\n";
  print CHECKIDSTAPLFILE "EXIT 0;\n";
  print CHECKIDSTAPLFILE "ENDPROC;\n";

  close(CHECKIDSTAPLFILE);
}


