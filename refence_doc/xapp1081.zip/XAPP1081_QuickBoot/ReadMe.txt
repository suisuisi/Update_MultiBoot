*************************************************************************
   ____  ____
  /   /\/   /
 /___/  \  /
 \   \   \/    � Copyright 2013 Xilinx, Inc. All rights reserved.
  \   \        This file contains confidential and proprietary
  /   /        information of Xilinx, Inc. and is protected under U.S.
 /___/   /\    and international copyright and other intellectual
 \   \  /  \   property laws.
  \___\/\___\

*************************************************************************

Vendor: Xilinx
Current readme.txt Version: 1.1
Date Last Modified: 05JUN2013
Date Created:  03MAR2013

Associated Filename: xapp1081.zip
Associated Document:
   XAPP1081, QuickBoot Method for FPGA Design Remote Update

Supported Device(s):  7 Series FPGAs

*************************************************************************

Disclaimer:

      This disclaimer is not a license and does not grant any rights to
      the materials distributed herewith. Except as otherwise provided in
      a valid license issued to you by Xilinx, and to the maximum extent
      permitted by applicable law: (1) THESE MATERIALS ARE MADE AVAILABLE
      "AS IS" AND WITH ALL FAULTS, AND XILINX HEREBY DISCLAIMS ALL
      WARRANTIES AND CONDITIONS, EXPRESS, IMPLIED, OR STATUTORY,
      INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
      NON-INFRINGEMENT, OR FITNESS FOR ANY PARTICULAR PURPOSE; and
      (2) Xilinx shall not be liable (whether in contract or tort,
      including negligence, or under any other theory of liability) for
      any loss or damage of any kind or nature related to, arising under
      or in connection with these materials, including for any direct, or
      any indirect, special, incidental, or consequential loss or damage
      (including loss of data, profits, goodwill, or any type of loss or
      damage suffered as a result of any action brought by a third party)
      even if such damage or loss was reasonably foreseeable or Xilinx
      had been advised of the possibility of the same.

Critical Applications:

      Xilinx products are not designed or intended to be fail-safe, or
      for use in any application requiring fail-safe performance, such as
      life-support or safety devices or systems, Class III medical
      devices, nuclear facilities, applications related to the deployment
      of airbags, or any other applications that could lead to death,
      personal injury, or severe property or environmental damage
      (individually and collectively, "Critical Applications"). Customer
      assumes the sole risk and liability of any use of Xilinx products
      in Critical Applications, subject only to applicable laws and
      regulations governing limitations on product liability.

THIS COPYRIGHT NOTICE AND DISCLAIMER MUST BE RETAINED AS PART OF THIS
FILE AT ALL TIMES.

*************************************************************************

This readme file contains these sections:

1. REVISION HISTORY
2. OVERVIEW
3. SOFTWARE TOOLS AND SYSTEM REQUIREMENTS
4. DESIGN FILE HIERARCHY
5. INSTALLATION AND OPERATING INSTRUCTIONS
6. OTHER INFORMATION
7. SUPPORT


1. REVISION HISTORY

            Readme
Date        Version      Revision Description
=========================================================================
03MAR2013   1.0          Initial Xilinx release.
05JUN2013   1.1          Added PrebuiltDemoFiles directory.
=========================================================================

2. OVERVIEW

This ReadMe.txt lists the files that come with XAPP1081.

The files and usage of the files is described in XAPP1081.

3. SOFTWARE TOOLS AND SYSTEM REQUIREMENTS

These files have been tested with Xilinx ISE 14.4 on a KC705 evaluation board.

4. DESIGN FILE HIERARCHY
  XAPP1081_QuickBoot\ReadMe.txt - this file
  XAPP1081_QuickBoot\PrebuiltDemoFiles\ - Directory of ready to use KC705 demo files
  XAPP1081_QuickBoot\PrebuiltDemoFiles\BpiQuickBootDemo1_initial.mcs - Initial BPI flash image for KC705 BPI demo. First use iMPACT to program the BPI flash with this image.
  XAPP1081_QuickBoot\PrebuiltDemoFiles\BpiQuickBootDemo2_update.svf  - After configuring the FPGA from the initial BPI flash image, use iMPACT to run this SVF to update the bitstream in BPI flash.
  XAPP1081_QuickBoot\PrebuiltDemoFiles\SpiQuickBootDemo1_initial.mcs - Initial SPI flash image for KC705 SPI demo. First use iMPACT to program the SPI flash with this image.
  XAPP1081_QuickBoot\PrebuiltDemoFiles\SpiQuickBootDemo2_update.svf  - After configuring the FPGA from the initial SPI flash image, use iMPACT to run this SVF to update the bitstream in SPI flash.

  XAPP1081_QuickBoot\PrebuiltDemoFiles\BpiQuickBootDemo1.bit - Demo design #1 bitstream for initial BPI flash image. Blinks GPIO_LED_7 once per period.
  XAPP1081_QuickBoot\PrebuiltDemoFiles\BpiQuickBootDemo1.msk - Demo design #1 mask file for initial BPI flash image. For verifying loaded design.
  XAPP1081_QuickBoot\PrebuiltDemoFiles\BpiQuickBootDemo2.bit - Demo design #2 bitstream for update BPI flash image. Blinks GPIO_LED_7 twice per period.
  XAPP1081_QuickBoot\PrebuiltDemoFiles\BpiQuickBootDemo2.msk - Demo design #2 mask file for initial BPI flash image. For verifying loaded design.
  XAPP1081_QuickBoot\PrebuiltDemoFiles\BpiQuickBootDemo2_update.mcs - Update flash image containing BpiQuickBootDemo2.bit.
  XAPP1081_QuickBoot\PrebuiltDemoFiles\BpiQuickBootDemo2_update_checkid.svf - Basic check of loaded BPI flash programmer and BPI flash memory.

  XAPP1081_QuickBoot\PrebuiltDemoFiles\SpiQuickBootDemo1.bit - Demo design #1 bitstream for initial SPI flash image. Blinks GPIO_LED_7 once per period.
  XAPP1081_QuickBoot\PrebuiltDemoFiles\SpiQuickBootDemo1.msk - Demo design #1 mask file for initial SPI flash image. For verifying loaded design.
  XAPP1081_QuickBoot\PrebuiltDemoFiles\SpiQuickBootDemo2.bit - Demo design #2 bitstream for update SPI flash image. Blinks GPIO_LED_7 twice per period.
  XAPP1081_QuickBoot\PrebuiltDemoFiles\SpiQuickBootDemo2.msk - Demo design #2 mask file for initial SPI flash image. For verifying loaded design.
  XAPP1081_QuickBoot\PrebuiltDemoFiles\SpiQuickBootDemo2_update.mcs - Update flash image containing SpiQuickBootDemo2.bit.
  XAPP1081_QuickBoot\PrebuiltDemoFiles\SpiQuickBootDemo2_update_checkid.svf - Basic check of loaded SPI flash programmer and SPI flash memory.


  XAPP1081_QuickBoot\MakeAllDemoFiles.bat - Windows batch script to remake all demo files in the BpiQuickBoot and SpiQuickBoot directory trees. Does NOT affect PrebuiltDemoFiles.
  XAPP1081_QuickBoot\CleanAllDemoFiles.bat - Windows batch script to clean-up all the demo file directories. Does NOT affect PrebuiltDemoFiles.
  XAPP1081_QuickBoot\QuickBoot Flash Memory Maps.xlsx - Excel version of flash memory maps in the XAPP1081 PDF.

  XAPP1081_QuickBoot\BpiQuickBoot\
  XAPP1081_QuickBoot\BpiQuickBoot\MakeBpiDemoFiles.bat - Windows batch script to remake BPI demo files
  XAPP1081_QuickBoot\BpiQuickBoot\impact_program_initial_demo1.cmd - Demo iMPACT batch script to program KC705 initial BPI flash image
                                                                     Run as: impact.exe -batch impact_program_initial_demo1.cmd
  XAPP1081_QuickBoot\BpiQuickBoot\impact_program_update_demo2.cmd - Demo iMPACT batch script to update KC705 initial BPI flash image
                                                                     Run as: impact.exe -batch impact_program_update_demo2.cmd
  XAPP1081_QuickBoot\BpiQuickBoot\BpiQuickBootDemo1\ - Contains KC705 demo design #1. Blinks GPIO_LED_7 once per period.
  XAPP1081_QuickBoot\BpiQuickBoot\BpiQuickBootDemo2\ - Contains KC705 demo design #2. Blinks GPIO_LED_7 twice per period.
  XAPP1081_QuickBoot\BpiQuickBoot\BpiFlashProgrammer\ - Contains source for BPI flash programmer
**XAPP1081_QuickBoot\BpiQuickBoot\BpiFlashProgrammer\BpiFlashProgrammer.vhd - BPI flash programmer reference design
  XAPP1081_QuickBoot\BpiQuickBoot\BpiFlashProgrammer\BpiFlashProgrammer_TB.vhd - BPI flash programmer simulation test bench
  XAPP1081_QuickBoot\BpiQuickBoot\BpiFlashProgrammer\BpiFlash.vhd - Pseudo model of BPI flash for simulation

  XAPP1081_QuickBoot\SpiQuickBoot\
  XAPP1081_QuickBoot\SpiQuickBoot\MakeSpiDemoFiles.bat - Windows batch script to remake SPI demo files
  XAPP1081_QuickBoot\SpiQuickBoot\impact_program_initial_demo1.cmd - Demo iMPACT batch script to program KC705 initial Spi flash image
                                                                     Run as: impact.exe -batch impact_program_initial_demo1.cmd
  XAPP1081_QuickBoot\SpiQuickBoot\impact_program_update_demo2.cmd - Demo iMPACT batch script to update KC705 initial Spi flash image
                                                                     Run as: impact.exe -batch impact_program_update_demo2.cmd
  XAPP1081_QuickBoot\SpiQuickBoot\SpiQuickBootDemo1\ - Contains KC705 demo design #1. Blinks GPIO_LED_7 once per period.
  XAPP1081_QuickBoot\SpiQuickBoot\SpiQuickBootDemo2\ - Contains KC705 demo design #2. Blinks GPIO_LED_7 twice per period.
  XAPP1081_QuickBoot\SpiQuickBoot\SpiFlashProgrammer\ - Contains source for SPI flash programmer
**XAPP1081_QuickBoot\SpiQuickBoot\SpiFlashProgrammer\SpiFlashProgrammer.vhd - SPI flash programmer reference design
**XAPP1081_QuickBoot\SpiQuickBoot\SpiFlashProgrammer\SpiSerDes.vhd - SPI serializer/deserializer reference design
  XAPP1081_QuickBoot\SpiQuickBoot\SpiFlashProgrammer\SpiFlashProgrammer_TB.vhd - SPI flash programmer simulation test bench
  XAPP1081_QuickBoot\SpiQuickBoot\SpiFlashProgrammer\N25Qxxx.vhd - Pseudo model of SPI flash for simulation

**FILES with "**" at the beginning of the line are the source code for the reference design.
  All other files are auxiliary files.


5. INSTALLATION AND OPERATING INSTRUCTIONS

  Unzip the xapp1081.zip.

  See the "KC705 Demonstrations" section in XAPP1081 for instructions on
  running the QuickBoot demos on the KC705.

  See the "QuickBoot Reference Design Implementation Guide" section in XAPP1081
  for instructions on implementing the QuickBoot reference design in an FPGA.

6. OTHER INFORMATION

7. SUPPORT

To obtain technical support for this reference design, go to
www.xilinx.com/support to locate answers to known issues in the Xilinx
Answers Database or to create a WebCase.

