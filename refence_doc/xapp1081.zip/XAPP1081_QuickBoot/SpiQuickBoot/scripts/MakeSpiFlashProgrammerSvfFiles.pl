##############################################################################
# Copyright � 2013, Xilinx, Inc.
# This design is confidential and proprietary of Xilinx, Inc. All Rights Reserved.
##############################################################################
#   ____  ____
#  /   /\/   /
# /___/  \  /   Vendor: Xilinx
# \   \   \/    Version: 1.00
#  \   \        Filename: MakeSpiFlashProgrammerSvfFiles.pl
#  /   /        Date Last Modified:  January 16, 2013
# /___/   /\    Date Created:        January 16, 2013
# \   \  /  \
#  \___\/\___\
#
#Devices:
#Purpose:
#Usage:
#Reference:
##############################################################################
#
#  Disclaimer: LIMITED WARRANTY AND DISCLAMER. These designs are
#              provided to you "as is." Xilinx and its licensors make and you
#              receive no warranties or conditions, express, implied,
#              statutory or otherwise, and Xilinx specifically disclaims any
#              implied warranties of merchantability, noninfringement, or
#              fitness for a particular purpose. Xilinx does not warrant that
#              the functions contained in these designs will meet your
#              requirements, or that the operation of these designs will be
#              uninterrupted or error free, or that defects in the Designs
#              will be corrected. Furthermore, Xilinx does not warrant or
#              make any representations regarding use or the results of the
#              use of the designs in terms of correctness, accuracy,
#              reliability, or otherwise.
#
#              LIMITATION OF LIABILITY. In no event will Xilinx or its
#              licensors be liable for any loss of data, lost profits, cost
#              or procurement of substitute goods or services, or for any
#              special, incidental, consequential, or indirect damages
#              arising from the use or operation of the designs or
#              accompanying documentation, however caused and on any theory
#              of liability. This limitation will apply even if Xilinx
#              has been advised of the possibility of such damage. This
#              limitation shall apply notwithstanding the failure of the
#              essential purpose of any limited remedies herein.
#
##############################################################################
# Revision History:
#   Revision (YYYY/MM/DD) - [User] Description
#   Rev 1.00 (2013/01/16) - [RMK] Created.
##############################################################################


##############################################################################
# Constants
##############################################################################

# JTAG instructions
$cJtagIRLength  = 6;
$cJtagUser1     = "02";
$cJtagUser2     = "03";
$cJtagJProgram  = "0B";

# SPI Flash
$cSizeSector      = 65536;
$cSizePage        = 256;
$cSizePageNP5Q    = 64;
$cMaxTimeBEN25Q   = 480;
$cMaxTimeSEN25Q   = 3;
$cMaxTimeSSEN25Q  = 0.8;
$cMaxTimePPN25Q   = 0.005;
$cIdcode24N25Q    = "20BA18";
$cIdcodeMask24N25Q= "FFFF00";
$cMaxTimeBEAtmel  = 0;
$cMaxTimeSEAtmel  = 0;
$cMaxTimeSSEAtmel = 0;
$cMaxTimePPAtmel  = 0.04;
$cIdcode24Atmel   = "1F2000";
$cIdcodeMask24Atmel="FFE000";
$cMaxTimeBENP5Q   = 0;
$cMaxTimeSENP5Q   = 0;
$cMaxTimeSSENP5Q  = 0;
$cMaxTimePPNP5Q   = 0.0036;
$cIdcode24NP5Q    = "20DA18";
$cIdcodeMask24NP5Q= "FFFF00";

# SpiFlashReader
# Reader JTAG opcode      = USER2 (000011)
# Reader data word width  = 32 bits
# Reader shift width      = 33 bits
# Reader data ready       = data[32]
# Reader data             = data[31:0]
# Reader first word time  = RUNTEST 120 TCK
# Reader next word time   = RUNTEST 60 TCK

# SpiFlashProgrammer
# Programmer JTAG opcode  = USER1 (000010)
# Programmer IDCODE       = RUNTEST 80 TCK

# Hex values
$hexval{"0000"} = "0";
$hexval{"0001"} = "1";
$hexval{"0010"} = "2";
$hexval{"0011"} = "3";
$hexval{"0100"} = "4";
$hexval{"0101"} = "5";
$hexval{"0110"} = "6";
$hexval{"0111"} = "7";
$hexval{"1000"} = "8";
$hexval{"1001"} = "9";
$hexval{"1010"} = "A";
$hexval{"1011"} = "B";
$hexval{"1100"} = "C";
$hexval{"1101"} = "D";
$hexval{"1110"} = "E";
$hexval{"1111"} = "F";
# Binary values
$binval{"0"} = "0000";
$binval{"1"} = "0001";
$binval{"2"} = "0010";
$binval{"3"} = "0011";
$binval{"4"} = "0100";
$binval{"5"} = "0101";
$binval{"6"} = "0110";
$binval{"7"} = "0111";
$binval{"8"} = "1000";
$binval{"9"} = "1001";
$binval{"A"} = "1010";
$binval{"B"} = "1011";
$binval{"C"} = "1100";
$binval{"D"} = "1101";
$binval{"E"} = "1110";
$binval{"F"} = "1111";
$binval{"a"} = "1010";
$binval{"b"} = "1011";
$binval{"c"} = "1100";
$binval{"d"} = "1101";
$binval{"e"} = "1110";
$binval{"f"} = "1111";


##############################################################################
# Globals
##############################################################################
@mcs  = ();

##############################################################################
# Subroutines
##############################################################################

##############################################################################
# Print Help
sub PrintHelp()
{
  print "Perl Script:  $0\n";
  print "Description:  Takes an input SpiFlashProgrammer MCS data file and\n";
  print "  outputs SVF files for driving the JtagToSpiFlashProgrammer module.\n";
  print "Usage:  perl $0 -tckfreq TF -hir A -tir B -hdr C -tdr D -be input.mcs\n";
  print " where\n";
  print "   -tckfreq TF = TCK frequency for the tool executing the SVF. (Default=6)\n";
  print "   -hir A      = header instruction register bit count. (Default=0)\n";
  print "   -tir B      = trailer instruction register bit count. (Default=0)\n";
  print "   -hdr C      = header data register bit count. (Default=0)\n";
  print "   -tdr D      = trailer data register bit count. (Default=0)\n";
  print "   -be         = Adjust for bulk erase. (Default=timed for sector erase.)\n";
  print "   -nosyncword = Do not check sync word erase/program flags\n";
  print "   -device D   = where D=\"NP5Q\" or \"Atmel\" device (Default=N25Q)\n";
  print "   -loadfpga   = Reload FPGA after programming update image.\n";
  print "   -maxruntest R = Break long RUNTESTs to multiple, with max R count.\n";
  print "                   (Default R=5000) For no breaks, set R=0\n";
  print "   input.mcs   = File name of input MCS data file.\n";
  exit;
}

##############################################################################
# sub:          subHexToBin
# Input:        $hex = String of hexadecimal characters
#               $len = Length of output binary string
# Output:       String of equivalent binary value.
# Description:  Convert hex to binary.
sub subHexToBin
{
  my $hex = shift(@_);
  my $len = shift(@_);
  if (!$len)
  {
    die "ERROR: Illegal subHexToBin length - $len\n";
  }
  $bin  = "";
  while (length($hex))
  {
    $hexchar  = substr($hex,0,1);
    $binset   = $binval{$hexchar};
    if (!length($binset))
    {
      die "ERROR: Illegal hex character = $hexchar\n";
    }
    $bin  .= $binset;
    $hex  = substr($hex,1);
  }
  while (length($bin)<$len)
  {
    $bin  = "0" . $bin;
  }
  while (length($bin)>$len)
  {
    $bin  = substr($bin,1);
  }
  return $bin;
}

##############################################################################
# sub:          subBinToHex
# Input:        $bin = String of binary characters
# Output:       String of equivalent hex value.
# Description:  Convert binary to hex.
sub subBinToHex
{
  my $bin = shift(@_);
  $hex  = "";
  while (length($bin)%4)
  {
    $bin  = "0" . $bin;
  }
  while (length($bin))
  {
    $hex  .= $hexval{substr($bin,0,4)};
    $bin  = substr($bin,4);
  }
  return $hex;
}


##############################################################################
# sub:          subTwosComplementChecksumOfHexStringOfBytes
# Input:        String of hexadecimal characters
# Output:       8-bit 2's-complement checksum
# Description:  Calculate the 8-bit, 2's-complement checksum from the given
#               string of hexadecimal characters as bytes (hex-char-pairs).
sub subTwosComplementChecksumOfHexStringOfBytes($)
{
  my $hexString = shift(@_);

  # Check for valid hex chars
  if ($hexString !~ /^[0-9A-Fa-f]+$/)
  {
    die "ERROR:  Invalid hex string:  $hexString\n";
  }

  # Check for hexadecimal character pairs for bytes
  my $hexStringLength = length($hexString);
  my $bytes           = $hexStringLength / 2;
  if ($hexStringLength % 2)
  {
    die "ERROR:  Invalid number of hex chars for hex-pair byte values\n";
  }

  # Compute checksum
  $checksum = 0;
  for ($i=0;$i<$bytes;$i++)
  {
    my $hexByte = substr($hexString,(2*$i),2);
    $checksum += hex($hexByte);
  }

  # Compute 8-bit two's complement
  $checksum = (($checksum ^ 0xFF) + 1) & 0xFF;

  return($checksum);
}

##############################################################################
# sub:          subBinRead
# Input:        $binFileName      = Input path\file name
# Output:       String of bytes as hex char pairs.
# Description:  Subroutine to read a pure binary file.
sub subBinRead
{
  my $binFileName = shift(@_);

  my $hexData     = "";

  if (!open(BINFILEREAD, "<$binFileName"))
  {
    print "ERROR:  Cannot open bin file:  $binFileName\n";
    die;
  }
  else
  {
    binmode(BINFILEREAD);
    print "INFO:  Reading BIN file:  $binFileName...\n";
  }


  while (!eof(BINFILEREAD))
  {
    $binByte  = getc(BINFILEREAD);
    $hexByte  = sprintf("%02X", ord($binByte));
    $hexData .= $hexByte;
  }
  close(BINFILEREAD);

  $hexDataLength  = length($hexData) / 2;

  printf("INFO:  Read BIN:   Data Start Address = %09d (0x%08X)\n",0,0);
  printf("INFO:  Read BIN:   Data End Address   = %09d (0x%08X)\n",($hexDataLength-1),($hexDataLength-1));
  printf("INFO:  Read BIN:   Data Length        = %09d (0x%08X)\n",$hexDataLength,$hexDataLength);

  return($hexData);
}


##############################################################################
# sub:          subHexRead
# Input:        $hexFileName      = Input path\file name
# Output:       String of bytes as hex char pairs.
# Description:  Subroutine to read an ASCII hex-pair stream of bytes.
#               Whitespace is ignored.
sub subHexRead
{
  my $hexFileName = shift(@_);

  my $hexData     = "";
  my $lineNumber  = 0;

  if (!open(HEXFILEREAD, "<$hexFileName"))
  {
    print "ERROR:  Cannot open hex file:  $hexFileName\n";
    die;
  }
  else
  {
    print "INFO:  Reading HEX file:  $hexFileName...\n";
  }

  while (<HEXFILEREAD>)
  {
    $lineNumber++;
    my $line        = "";
    my $inputLineLen= length($_);

    # Strip whitespace
    for (my $i=0;$i<$inputLineLen;$i++)
    {
      my $char  = substr($_,$i,1);
      if ($char =~ /[0-9A-Fa-f]/)
      {
        $line .= $char;
      }
      elsif ($char =~ /\S/)
      {
        die "ERROR:  Non-hex char ($char) on line number $lineNumber\n";
      }
    }
    my $lineLength  = length($line);

    if ($lineLength % 2)
    {
      print "WARNING:  Number of hex characters is not a multiple of 2 on line number $lineNumber\n";
    }

    $hexData  .= $line;
  }
  close(HEXFILEREAD);

  if (length($hexData) % 2)
  {
    die "ERROR:  Number of hex characters is not a multiple of 2 (Note: 2 chars/byte)\n";
  }


  $hexDataLength  = length($hexData) / 2;

  printf("INFO:  Read HEX:   Data Start Address = %09d (0x%08X)\n",0,0);
  printf("INFO:  Read HEX:   Data End Address   = %09d (0x%08X)\n",($hexDataLength-1),($hexDataLength-1));
  printf("INFO:  Read HEX:   Data Length        = %09d (0x%08X)\n",$hexDataLength,$hexDataLength);

  return($hexData);
}


##############################################################################
# sub:          subMcsRead
# Input:        $mcsFileName      = Input .MCS path\file name
#               $mcsFill          = [Optional] Byte value (2-char hex pair)
#                                   to fill gaps.
#               $mcsFillFromZero  = [Optional] Byte value (2-char hex pair)
#                                   to fill a gap from address zero.
# Output:       String of bytes as hex char pairs.  If a gap is not filled,
#               a "XX<ADDR>" string can be found in the return value where
#               <ADDR> is a 32-bit (8-char) hex value that represents the byte
#               address for the first byte of data in the next set.
# Description:  Subroutine to read a .MCS file.
sub subMcsRead
{
  my $mcsFileName           = shift(@_);
  my $mcsFill               = shift(@_);
  my $mcsFillFromZero       = shift(@_);

  my $mcsDataHex            = "";
  my $mcsDataAddressStart   = -1;
  my $mcsDataAddressCurrent = 0;
  my $mcsGaps               = 0;
  my $mcsSegmentAddress     = 0;
  my $mcsStartSegmentAddress= "";
  my $mcsStartLinearAddress = "";
  my $lineNumber            = 0;
  my $eof                   = 0;

  if (!open(MCSFILEREAD, "<$mcsFileName"))
  {
    print "ERROR:  Cannot open .MCS file:  $mcsFileName\n";
    die;
  }
  else
  {
    print "INFO:  Reading MCS file:  $mcsFileName...\n";
  }

  while (<MCSFILEREAD>)
  {
    $lineNumber++;
    my $errorMsg    = "";
    my $warningMsg  = "";

    # Strip trailing whitespace
    while ($_ =~ /\s$/)
    {
      chomp;
    }
    my $lineLength  = length($_);

    # Check for a valid record
    if ($_ =~ /^\s*$/)
    {
      if (!$eof)
      {
        $warningMsg .= "WARNING:  Found empty line.\n";
      }
    }
    elsif ($eof)
    {
      $warningMsg .= "WARNING:  Extra information after end of file record\n";
    }
    elsif ($_ !~ /^\:/)
    {
      $errorMsg = sprintf("ERROR:  Expected line to begin with Record Mark ':', but found: '%s'\n", substr($_,0,1));
    }
    elsif ($lineLength < 11)
    {
      $errorMsg = "ERROR:  Insufficient characters ($lineLength) on line for a valid record\n";
    }
    elsif ($_ =~ /^\:([0-9A-Fa-f]{2})([0-9A-Fa-f]{4})([0-9A-Fa-f]{2})([0-9A-Fa-f]*)([0-9A-Fa-f]{2})$/)
    {
      my $mcsLineRecLenHex      = $1;
      my $mcsLineRecLen         = hex($mcsLineRecLenHex);
      my $mcsLineLoadOffsetHex  = $2;
      my $mcsLineLoadOffset     = hex($mcsLineLoadOffsetHex);
      my $mcsLineRecTypHex      = $3;
      my $mcsLineDataHex        = $4;
      my $mcsLineDataLength     = length($mcsLineDataHex);
      my $mcsLineDataBytes      = $mcsLineDataLength / 2;
      my $mcsLineChksumHex      = $5;
      my $mcsLineChksum         = hex($mcsLineChksumHex);
      my $mcsLineCalcChksum     = subTwosComplementChecksumOfHexStringOfBytes(substr($_,1,($lineLength-3)));
      my $mcsLineCalcChksumHex  = sprintf("%02X",$mcsLineCalcChksum);

      if ($mcsLineDataLength % 2)
      {
        $errorMsg = "ERROR:  Number of hex data characters is not a multiple of 2 (2 chars/byte)\n";
      }
      elsif ($mcsLineRecLen != $mcsLineDataBytes)
      {
        $errorMsg = "ERROR:  Record Length = $mcsLineRecLen, but actual data bytes count = $mcsLineDataBytes\n";
      }
      elsif ($mcsLineRecTypHex eq "00")
      {
        if ($mcsLineCalcChksum ne $mcsLineChksum)
        {
          $warningMsg .= "WARNING:  Checksum error.  Expected \"$mcsLineCalcChksumHex\", but found \"$mcsLineChksumHex\"\n";
        }

        # Data record
        if ($mcsLineRecLen)
        {
          # Check for gaps and fill as specified
          $mcsLineByteAddress = $mcsSegmentAddress + $mcsLineLoadOffset;
          if ($mcsDataHex eq "")
          {
            if ($mcsFillFromZero ne "")
            {
              while ($mcsDataAddressCurrent < $mcsLineByteAddress)
              {
                $mcsDataHex .= $mcsFillFromZero;
                $mcsDataAddressCurrent++;
              }
              if ($mcsDataAddressStart == -1) {$mcsDataAddressStart=0;}
            }
            elsif ($mcsDataAddressCurrent < $mcsLineByteAddress)
            {
              #$warningMsg .= sprintf("WARNING:  Gap from 0x%08X to 0x%08X\n",
              #                       $mcsDataAddressCurrent, $mcsLineByteAddress);
              $mcsGaps++;
              $mcsDataHex .= "XX"; # Gap;  Mark new address with "XX"
              $mcsDataHex .= sprintf("%08X",$mcsLineByteAddress);
              $mcsDataAddressCurrent  = $mcsLineByteAddress;
              if ($mcsDataAddressStart == -1) {$mcsDataAddressStart=$mcsDataAddressCurrent;}
            }
            elsif ($mcsDataAddressStart == -1)
            {
              $mcsDataAddressStart=$mcsDataAddressCurrent;
            }
          }
          elsif ($mcsFill ne "")
          {
            while ($mcsDataAddressCurrent < $mcsLineByteAddress)
            {
              $mcsDataHex .= $mcsFill;
              $mcsDataAddressCurrent++;
            }
          }
          elsif ($mcsDataAddressCurrent < $mcsLineByteAddress)
          {
            #$warningMsg .= sprintf("WARNING:  Gap from 0x%08X to 0x%08X\n",
            #                       $mcsDataAddressCurrent, $mcsLineByteAddress);
            $mcsGaps++;
            $mcsDataHex .= "XX"; # Gap;  Mark new address with "XX"
            $mcsDataHex .= sprintf("%08X",$mcsLineByteAddress);
            $mcsDataAddressCurrent  = $mcsLineByteAddress;
          }

          # Place the data from the line
          $mcsDataHex .= $mcsLineDataHex;
          $mcsDataAddressCurrent  += $mcsLineDataBytes;
        }
      }
      elsif ($mcsLineRecTypHex eq "01")
      {
        if ($mcsLineCalcChksum ne $mcsLineChksum)
        {
          $warningMsg .= "WARNING:  Checksum error.  Expected \"$mcsLineCalcChksumHex\", but found \"$mcsLineChksumHex\"\n";
        }
        # End of file record
        if ($mcsLineRecLenHex ne "00")
        {
          $warningMsg .= "WARNING:  Expected \"00\" for record length, but found \"$mcsLineRecLenHex\"\n";
        }
        if ($mcsLineLoadOffsetHex ne "0000")
        {
          $warningMsg .= "WARNING:  Expected \"0000\" for load offset, but found \"$mcsLineLoadOffsetHex\"\n";
        }
        $eof  = 1;
      }
      elsif ($mcsLineRecTypHex eq "02")
      {
        if ($mcsLineCalcChksum ne $mcsLineChksum)
        {
          $warningMsg .= "WARNING:  Checksum error.  Expected \"$mcsLineCalcChksumHex\", but found \"$mcsLineChksumHex\"\n";
        }
        # Extended segment address record
        if ($mcsLineRecLenHex ne "02")
        {
          $errorMsg = "ERROR:  Expected \"02\" for record length, but found \"$mcsLineRecLenHex\"\n";
        }
        else
        {
          if ($mcsLineLoadOffsetHex ne "0000")
          {
            $warningMsg .= "WARNING:  Expected \"0000\" for load offset, but found \"$mcsLineLoadOffsetHex\"\n";
          }
          $mcsSegmentAddressHex = $mcsLineDataHex . "0";
          $mcsSegmentAddress    = hex($mcsSegmentAddressHex);
          if ($mcsSegmentAddress < $mcsDataAddressCurrent)
          {
            $errorMsg = "ERROR:  Extended segment address record is not sequential\n";
          }
        }
      }
      elsif ($mcsLineRecTypHex eq "03")
      {
        if ($mcsLineCalcChksum ne $mcsLineChksum)
        {
          $warningMsg .= "WARNING:  Checksum error.  Expected \"$mcsLineCalcChksumHex\", but found \"$mcsLineChksumHex\"\n";
        }
        # Start segment address record
        if ($mcsLineRecLenHex ne "04")
        {
          $errorMsg = "ERROR:  Expected \"04\" for record length, but found \"$mcsLineRecLenHex\"\n";
        }
        else
        {
          if ($mcsLineLoadOffsetHex ne "0000")
          {
            $warningMsg .= "WARNING:  Expected \"0000\" for load offset, but found \"$mcsLineLoadOffsetHex\"\n";
          }
          if (length($mcsLineStartSegmentAddress))
          {
            $warningMsg .= "WARNING:  Found more than one start segment address record.\n";
          }
          $mcsLineStartSegmentAddress = $mcsLineDataHex;
          $warningMsg .= "WARNING:  Ignoring start segment address ($mcsLineStartSegmentAddress) record.\n";
        }
      }
      elsif ($mcsLineRecTypHex eq "04")
      {
        if ($mcsLineCalcChksum ne $mcsLineChksum)
        {
          $warningMsg .= "WARNING:  Checksum error.  Expected \"$mcsLineCalcChksumHex\", but found \"$mcsLineChksumHex\"\n";
        }
        # Extended linear address record
        if ($mcsLineRecLenHex ne "02")
        {
          $errorMsg = "ERROR:  Expected \"02\" for record length, but found \"$mcsLineRecLenHex\"\n";
        }
        else
        {
          if ($mcsLineLoadOffsetHex ne "0000")
          {
            $warningMsg .= "WARNING:  Expected \"0000\" for load offset, but found \"$mcsLineLoadOffsetHex\"\n";
          }
          $mcsSegmentAddressHex = $mcsLineDataHex . "0000";
          $mcsSegmentAddress    = hex($mcsSegmentAddressHex);
          if ($mcsSegmentAddress < $mcsDataAddressCurrent)
          {
            $errorMsg = "ERROR:  Extended linear address record is not sequential\n";
          }
        }
      }
      elsif ($mcsLineRecTypHex eq "05")
      {
        if ($mcsLineCalcChksum ne $mcsLineChksum)
        {
          $warningMsg .= "WARNING:  Checksum error.  Expected \"$mcsLineCalcChksumHex\", but found \"$mcsLineChksumHex\"\n";
        }
        # Start linear address record
        if ($mcsLineRecLenHex ne "04")
        {
          $errorMsg .= "WARNING:  Expected \"04\" for record length, but found \"$mcsLineRecLenHex\"\n";
        }
        else
        {
          if ($mcsLineLoadOffsetHex ne "0000")
          {
            $warningMsg .= "WARNING:  Expected \"0000\" for load offset, but found \"$mcsLineLoadOffsetHex\"\n";
          }
          if (length($mcsLineStartLinearAddress))
          {
            $warningMsg .= "WARNING:  Found more than one start linear address record.\n";
          }
          $mcsLineStartLinearAddress  = $mcsLineDataHex;
          $warningMsg .= "WARNING:  Ignoring start linear address ($mcsLineStartLinearAddress) record.\n";
        }
      }
      else
      {
        $errorMsg = "ERROR:  Unrecognized record type '$mcsLineRecTypHex'\n";
      }
    }
    else
    {
      $errorMsg = "ERROR:  Invalid (non-hexadecimal) characters on line\n";
    }

    if (length($errorMsg)||length($warningMsg))
    {
      print "$warningMsg$errorMsg";
      print "  LINE[$lineNumber]: \"$_\"\n";
      if (length($errorMsg))
      {
        die;
      }
    }
  }
  close(MCSFILEREAD);

  my $mcsDataLength     = $mcsDataAddressCurrent - $mcsDataAddressStart;
  my $mcsDataAddressEnd = $mcsDataAddressCurrent - 1;
  printf("INFO:  Read MCS:   Data Start Address = %09d (0x%08X)\n",$mcsDataAddressStart,$mcsDataAddressStart);
  printf("INFO:  Read MCS:   Data End Address   = %09d (0x%08X)\n",$mcsDataAddressEnd,$mcsDataAddressEnd);
  printf("INFO:  Read MCS:   Data Length        = %09d (0x%08X)\n",$mcsDataLength,$mcsDataLength);

  return($mcsDataHex);
}


##############################################################################
# sub:          subGenerateRuntest
# Input:        $tckCount = TCK cycles for RUNTEST.
#               $optMaxRuntest  = max count per runtest/wait;
# Output:       String of RUNTEST statement(s).
# Description:
sub subGenerateRuntest
{
  my $tckCount      = shift(@_);
  my $optMaxRuntest = shift(@_);
  my $prefix        = shift(@_);
  my $runtest       = "";

  if ($optMaxRuntest > 0)
  {
    while ($tckCount > $optMaxRuntest)
    {
      $runtest  .= $prefix;
      $runtest  .= "RUNTEST $optMaxRuntest TCK;\n";
      $tckCount -=  $optMaxRuntest;
    }
  }

  if ($tckCount > 0)
  {
    $runtest  .= $prefix;
    $runtest  .= "RUNTEST $tckCount TCK;";
  }

  return($runtest);
}

##############################################################################
# Main
##############################################################################

my  $optHir     = 0;
my  $optTir     = 0;
my  $optHdr     = 0;
my  $optTdr     = 0;
my  $optBulkErase=0;
my  $optLoadFpga= 0;
my  $optMaxRuntest= 5000;
my  $optCheckStatus=0;
my  $optCheckSyncword=1;
my  $optTckFreqMHz= 6;
my  $optDevice  ="N25Q";

##############################################################################
# Process command-line arguments

##### No arguments or -h, then print the help
if ((@ARGV==0) || (lc($ARGV[0]) eq "-h"))
{
  PrintHelp();
}

##### Process command-line switches
while ($ARGV[0] =~ /^-/)
{
  if (lc($ARGV[0]) =~ /^-tckfreq/)
  {
    shift;
    $optTckFreqMHz = $ARGV[0];
    print("INFO:  -tckfreq set to: $optTckFreqMHz\n");
  }
  elsif (lc($ARGV[0]) =~ /^-hir/)
  {
    shift;
    $optHir = $ARGV[0];
    print("INFO:  -hir set to: $optHir\n");
  }
  elsif (lc($ARGV[0]) =~ /^-tir/)
  {
    shift;
    $optTir = $ARGV[0];
    print("INFO:  -tir set to: $optTir\n");
  }
  elsif (lc($ARGV[0]) =~ /^-hdr/)
  {
    shift;
    $optHdr = $ARGV[0];
    print("INFO:  -hdr set to: $optHdr\n");
  }
  elsif (lc($ARGV[0]) =~ /^-tdr/)
  {
    shift;
    $optTdr = $ARGV[0];
    print("INFO:  -tdr set to: $optTdr\n");
  }
  elsif (lc($ARGV[0]) =~ /^-be/)
  {
    $optBulkErase = 1;
    $optCheckSyncword = 0;  # If bulk erase, then no syncword erase/program
    print("INFO:  -be = adjusted timing for bulk erase.\n");
    print("INFO:        Also, set -nosyncword.\n");
  }
  elsif (lc($ARGV[0]) =~ /^-loadfpga/)
  {
    $optLoadFpga = 1;
    print("INFO:  -loadfpga = Reload FPGA after programming update image.\n");
  }
  elsif (lc($ARGV[0]) =~ /^-nosyncword/)
  {
    $optCheckSyncword = 0;
    print("INFO:  -nosyncword = Do not check syncword erase/program flags.\n");
  }
  elsif (lc($ARGV[0]) =~ /^-maxruntest/)
  {
    shift;
    $optMaxRuntest = $ARGV[0];
    print("INFO:  -maxruntest set to: $optMaxRuntest\n");
  }
  elsif (lc($ARGV[0]) =~ /^-checkstatus/)
  {
    $optCheckStatus = 1;
    print("INFO:  -checkstatus = for debug, insert TDO checks for ready status.\n");
  }
  elsif (lc($ARGV[0]) =~ /^-device/)
  {
    shift;
    $optDevice = uc($ARGV[0]);
    if ($optDevice eq "N25Q")
    {
      print("INFO:  -device N25Q = Micron N25Q device.\n");
    }
    elsif ($optDevice eq "NP5Q")
    {
      print("INFO:  -device NP5Q = adjust for Micron NP5Q device.\n");
    }
    elsif ($optDevice eq "ATMEL")
    {
      print("INFO:  -device Atmel = adjust for Atmel DataFlash device.\n");
    }
    elsif ($optDevice eq "S3AN")
    {
      $optDevice  = "ATMEL";
      print("INFO:  -device S3AN = adjust for Atmel DataFlash device.\n");
    }
    else
    {
      print("WARNING:  Did not recognize -device $optDevice.  Ignoring.\n");
      $optDevice  = "N25Q";
    }
  }
  else
  {
    print("WARNING:  Did not recognize command-line option: $ARGV[0]\n");
  }
  shift;
}

$cClkFrequencyHz= int($optTckFreqMHz * 1000000);
if ($optDevice eq "NP5Q")
{
  $cCmdBETimeOut  = int($cClkFrequencyHz * $cMaxTimeBENP5Q);
  $cCmdSETimeOut  = int($cClkFrequencyHz * $cMaxTimeSENP5Q);
  $cCmdSSETimeOut = int($cClkFrequencyHz * $cMaxTimeSSENP5Q);
  $cCmdPPTimeOut  = int($cClkFrequencyHz * $cMaxTimePPNP5Q);
  $cSizePage      = $cSizePageNP5Q;
  $cIdcode24      = $cIdcode24NP5Q;
  $cIdcodeMask24  = $cIdcodeMask24NP5Q;
}
elsif ($optDevice eq "ATMEL")
{
  $cCmdBETimeOut  = int($cClkFrequencyHz * $cMaxTimeBEAtmel);
  $cCmdSETimeOut  = int($cClkFrequencyHz * $cMaxTimeSEAtmel);
  $cCmdSSETimeOut = int($cClkFrequencyHz * $cMaxTimeSSEAtmel);
  $cCmdPPTimeOut  = int($cClkFrequencyHz * $cMaxTimePPAtmel);
  $cIdcode24      = $cIdcode24Atmel;
  $cIdcodeMask24  = $cIdcodeMask24Atmel;
}
else
{
  $cCmdBETimeOut  = int($cClkFrequencyHz * $cMaxTimeBEN25Q);
  $cCmdSETimeOut  = int($cClkFrequencyHz * $cMaxTimeSEN25Q);
  $cCmdSSETimeOut = int($cClkFrequencyHz * $cMaxTimeSSEN25Q);
  $cCmdPPTimeOut  = int($cClkFrequencyHz * $cMaxTimePPN25Q);
  $cIdcode24      = $cIdcode24N25Q;
  $cIdcodeMask24  = $cIdcodeMask24N25Q;
}


my  $fileNameMcsInput   = $ARGV[0];
print("INFO:  Input MCS file name set to: $fileNameMcsInput\n");
my  $fileNameType       = substr($fileNameMcsInput,-4,4);
if (lc($fileNameType) ne ".mcs")
{
  die "ERROR: Input file $fileNameMcsInput is not a .mcs file\n";
}
my  $fileNameRoot       = substr($fileNameMcsInput,0,-4);
if (length($fileNameRoot) == 0)
{
  die "ERROR: Invalid input file $fileNameMcsInput\n";
}
my  $fileNameSvf  = $fileNameRoot . ".svf";
my  $fileNameCheckIdSvf = $fileNameRoot . "_checkid.svf";
my  $fileNameVerifySvf  = $fileNameRoot . "_verify.svf";
my  $fileNameReadbackSvf= $fileNameRoot . "_readback.svf";
my  $fileNameReadIdSvf  = $fileNameRoot . "_read_id.svf";

print "INFO:  TCK Frequency                 = $cClkFrequencyHz Hz\n";
print "INFO:  HIR                           = $optHir bits\n";
print "INFO:  TIR                           = $optTir bits\n";
print "INFO:  HDR                           = $optHdr bits\n";
print "INFO:  TDR                           = $optTdr bits\n";
print "INFO:  Max RUNTEST                   = $optMaxRuntest TCK cycles\n";
print "INFO:  Device                        = $optDevice\n";
print "INFO:  Input MCS file name           = $fileNameMcsInput\n";
print "INFO:  Output SVF file name          = $fileNameSvf\n";
print "INFO:  Output check ID SVF file name = $fileNameCheckIdSvf\n";
print "INFO:  Output verify SVF file name   = $fileNameVerifySvf\n";
print "INFO:  Output readback SVF file name = $fileNameReadbackSvf\n";
print "INFO:  Output read ID SVF file name  = $fileNameReadIdSvf\n";

# Setup HIR/TIR/HDR/TDR
if (($optHir==0)&&($optTir==0)&&($optHdr==0)&&($optTdr==0))
{
  $HirTirHdrTdr = "//---------------------------------------------------------\n"
                . "//If other devices in scan chain, set HIR/TIR/HDR/TDR below\n"
                . "//HIR N TDI(FF); // Set N length and TDI to all ones\n"
                . "//TIR M TDI(FF); // Set M length and TDI to all ones\n"
                . "//HDR X TDI(00); // Set X length and TDI to all zeros\n"
                . "//TDR Y TDI(00); // Set Y length and TDI to all zeros\n"
                . "//---------------------------------------------------------"
}
else
{
  $HirTirHdrTdr = "";
  if ($optHir=0)
  {
    $HirTirHdrTdr .= "HIR 0;\n";
  }
  else
  {
    $ones = "";
    for ($i=0;$i<$optHir;$i++)
    {
      $ones = $ones . "1";
    }
    $HirTirHdrTdr .= "HIR $optHir TDI(" . bin2hex($ones) . ");\n";
  }
  if ($optTir=0)
  {
    $HirTirHdrTdr .= "TIR 0;\n";
  }
  else
  {
    $ones = "";
    for ($i=0;$i<$optTir;$i++)
    {
      $ones = $ones . "1";
    }
    $HirTirHdrTdr .= "TIR $optTir TDI(" . bin2hex($ones) . ");\n";
  }
  if ($optHdr=0)
  {
    $HirTirHdrTdr .= "HDR 0;\n";
  }
  else
  {
    $HirTirHdrTdr .= "HDR $optHdr TDI(0);\n";
  }
  if ($optTdr=0)
  {
    $HirTirHdrTdr .= "TDR 0;\n";
  }
  else
  {
    $HirTirHdrTdr .= "TDR $optTdr TDI(0);";
  }
}

my $mcsDataHex = subMcsRead($fileNameMcsInput);
my $mcsDataStartAddr    = 0;
my $mcsDataStartAddrHex = "00000000";
if (substr($mcsDataHex,0,2) eq "XX")
{
  $mcsDataStartAddrHex  = substr($mcsDataHex,2,8);
  $mcsDataStartAddr     = hex($mcsDataStartAddrHex);
  $mcsDataHex           = substr($mcsDataHex,10);
}
if (index($mcsDataHex,"XX")>=0)
{
  die "ERROR:  Input MCS data has unexpected gaps in defined data.\n";
}
my $mcsDataLength = length($mcsDataHex) / 2;
if ($mcsDataLength==0)
{
  die "ERROR:  Input MCS has no data\n";
}
my $numSectors  = $mcsDataLength / $cSizeSector;
if ($mcsDataLength != ($numSectors * $cSizeSector))
{
  die "ERROR:  Input MCS data length is not a multiple of the flash sector size.";
}
my $numPages    = $mcsDataLength / $cSizePage;
print "INFO:  Number of sectors = $numSectors\n";
print "INFO:  Number of pages   = $numPages\n";

# Prepare to write SVF file
if (!open(SVFFILE, ">$fileNameSvf"))
{
  print "ERROR:  Cannot open .SVF file:  $fileNameSvf\n";
  die;
}
else
{
  print "INFO:  Writing SVF file:  $fileNameSvf\n";

  if ($optCheckSyncword == 1)
  {
    $tdoMask = "0000FFFF";
  }
  else
  {
    $tdoMask = "000077FF";
  }

  print SVFFILE "//FREQUENCY $cClkFrequencyHz HZ;\n"; # Comment out -- iMPACT bug
  print SVFFILE "$HirTirHdrTdr\n";
  print SVFFILE "STATE RESET;\n";
  print SVFFILE "ENDIR IDLE;\n";
  print SVFFILE "ENDDR IDLE;\n";
  print SVFFILE "// Load USER1 instruction to access the SpiFlashProgrammer\n";
  print SVFFILE "SIR $cJtagIRLength TDI($cJtagUser1);\n";
  print SVFFILE "// Activate programmer.\n";
  print SVFFILE "SDR 32 TDI(0000CA75);\n";
  print SVFFILE "// Wait to initialize and read ID\n";
  $tckMax = 80;
  if (($optDevice eq "NP5Q") or ($optDevice eq "ATMEL"))
  {
    if ($optCheckSyncword==1)
    {
      print SVFFILE "// Wait to corrupt sync word\n";
      $tckMax += 150;             # Send WE and PP to corrupt sync word
      $tckMax += $cCmdPPTimeOut;  # Wait for PP to corrupt sync word
    }
  }
  else
  {
    printf(SVFFILE "%s\n", subGenerateRuntest($tckMax,$optMaxRuntest,""));;
    $tckMax = 0;
    print SVFFILE "// Check ID OK\n";
    print SVFFILE "SDR 32 TDI(00000000) TDO(00000700) MASK($tdoMask);\n";
    print SVFFILE "// Wait to erase\n";
    if ($optBulkErase==1)
    {
      $tckMax += 150;             # Send WE and BE to erase device
      $tckMax += $cCmdBETimeOut   # Wait for BE to complete
    }
    else
    {
      if ($optCheckSyncword==1)
      {
        $tckMax += 150;             # Send WE and SSE to erase sync word
        $tckMax += $cCmdSSETimeOut;  # Wait for SSE erase sync word
      }
      $tckMax += ($numSectors * (150 + $cCmdSETimeOut));
    }
  }
  $tckMax += 110;             # Send WE and PP for first page program
  printf(SVFFILE "%s\n", subGenerateRuntest($tckMax,$optMaxRuntest,""));;
  $tckMax = 0;
  print SVFFILE "// Load data for page programming\n";
  my $words = $cSizePage / 4;
  for ($i=0;$i<$numPages;$i++)
  {
    for ($j=0;$j<$words;$j++)
    {
      if ($j>0)
      {
        print SVFFILE "RUNTEST 40 TCK;\n";
      }
      $offset = (($i * $cSizePage * 2) + ($j * 8));
      $word   = substr($mcsDataHex,$offset,8);
      print SVFFILE "SDR 32 TDI($word) TDO(00001F01) MASK($tdoMask);\n";
    }
    $tckMax = $cCmdPPTimeOut + 150; # Wait PP Max and write next WE and PP
    print SVFFILE "// Wait to program page\n";
    printf(SVFFILE "%s\n", subGenerateRuntest($tckMax, $optMaxRuntest,""));;
  }

  print SVFFILE "// Check program stage done\n";
  print SVFFILE "SDR 32 TDI($word) TDO(00003F00) MASK($tdoMask);\n";

  print SVFFILE "// Verify via CRC check\n";
  $tckMax = 500; # Send READ + address + extra margin
  $tckMax += ($mcsDataLength * 11);  # 11 CLK cycles per byte
  if ($optCheckSyncword==1)
  {
    $tckMax += 150 + $cCmdPPTimeOut; # Add syncword program time
  }
  printf(SVFFILE "%s\n", subGenerateRuntest($tckMax, $optMaxRuntest,""));;

  print SVFFILE "// Check DONE\n";
  print SVFFILE "SDR 32 TDI(00000000) TDO(0000FF03) MASK($tdoMask);\n";
  if ($optLoadFpga == 1)
  {
    print SVFFILE "// Reload FPGA\n";
    print SVFFILE "SIR $cJtagIRLength TDI($cJtagJProgram);\n";
  }
  print SVFFILE "STATE RESET;\n";
  print SVFFILE "\n";
  close(SVFFILE);
}

# Prepare to write verify only SVF file
if (!open(VERIFYSVFFILE, ">$fileNameVerifySvf"))
{
  print "ERROR:  Cannot open .SVF file:  $fileNameVerifySvf\n";
  die;
}
else
{
  print "INFO:  Writing verify-only SVF file:  $fileNameVerifySvf\n";

  print VERIFYSVFFILE "$HirTirHdrTdr\n";
  print VERIFYSVFFILE "STATE RESET;\n";
  print VERIFYSVFFILE "ENDIR IDLE;\n";
  print VERIFYSVFFILE "ENDDR IDLE;\n";
  print VERIFYSVFFILE "// Load USER1 instruction to access the SpiFlashProgrammer\n";
  print VERIFYSVFFILE "SIR $cJtagIRLength TDI($cJtagUser1);\n";
  print VERIFYSVFFILE "// Activate programmer verify-only option.\n";
  print VERIFYSVFFILE "SDR 32 TDI(00001423);\n";
  print VERIFYSVFFILE "// Wait to initialize and read ID\n";
  print VERIFYSVFFILE "RUNTEST 80 TCK;\n";
  print VERIFYSVFFILE "// Check ID OK\n";
  print VERIFYSVFFILE "SDR 32 TDI(00000000) TDO(00000700) MASK(0000FFFF);\n";

  print VERIFYSVFFILE "// Verify via CRC check\n";
  $tckMax = 500; # Send READ + address + extra margin
  $tckMax = $tckMax + ($mcsDataLength * 11);  # 11 CLK cycles per byte
  $tckMax = $tckMax + $cCmdPPTimeOut; # Add syncword program time
  printf(VERIFYSVFFILE "%s\n", subGenerateRuntest($tckMax, $optMaxRuntest,""));;

  print VERIFYSVFFILE "// Check DONE\n";
  print VERIFYSVFFILE "SDR 32 TDI(00000000) TDO(00004703) MASK(0000FFFF);\n";
  print VERIFYSVFFILE "STATE RESET;\n";
  print VERIFYSVFFILE "\n";
  close(VERIFYSVFFILE);
}

# Prepare to write check ID SVF file
if (!open(CHECKIDSVFFILE, ">$fileNameCheckIdSvf"))
{
  print "ERROR:  Cannot open .SVF file:  $fileNameCheckIdSvf\n";
  die;
}
else
{
  print "INFO:  Writing SVF file:  $fileNameCheckIdSvf\n";

  print CHECKIDSVFFILE "$HirTirHdrTdr\n";
  print CHECKIDSVFFILE "STATE RESET;\n";
  print CHECKIDSVFFILE "ENDIR IDLE;\n";
  print CHECKIDSVFFILE "ENDDR IDLE;\n";
  print CHECKIDSVFFILE "// Load USER1 instruction to access the SpiFlashProgrammer\n";
  print CHECKIDSVFFILE "SIR $cJtagIRLength TDI($cJtagUser1);\n";
  print CHECKIDSVFFILE "// Activate check-ID-only.\n";
  print CHECKIDSVFFILE "SDR 32 TDI(00001DCD);\n";
  print CHECKIDSVFFILE "// Wait to initialize and read IDCODE\n";
  print CHECKIDSVFFILE "RUNTEST 80 TCK;\n";
  print CHECKIDSVFFILE "// Check for DONE with no error flags\n";
  print CHECKIDSVFFILE "SDR 32 TDI(00000000) TDO(00000703) MASK($tdoMask);\n";
  print CHECKIDSVFFILE "STATE RESET;\n";
  close(CHECKIDSVFFILE);
}

# Prepare to write READBACK SVF file
if (!open(READBACKSVFFILE, ">$fileNameReadbackSvf"))
{
  print "ERROR:  Cannot open .SVF file:  $fileNameReadbackSvf\n";
  die;
}
else
{
  if (($mcsDataLength % 4)!=0)
  {
    print "WARNING:  Input MCS data length is not a multiple of 4 for 4-byte words.\n";
  }
  print "INFO:  Writing SVF file:  $fileNameReadbackSvf\n";

  print READBACKSVFFILE "$HirTirHdrTdr\n";
  print READBACKSVFFILE "STATE RESET;\n";
  print READBACKSVFFILE "ENDIR IDLE;\n";
  print READBACKSVFFILE "ENDDR IDLE;\n";
  print READBACKSVFFILE "// Load USER2 instruction to access the SpiFlashReader\n";
  print READBACKSVFFILE "SIR $cJtagIRLength TDI($cJtagUser2);\n";
  print READBACKSVFFILE "// Load readback start address\n";
  print READBACKSVFFILE "SDR 33 TDI(0$mcsDataStartAddrHex);\n";
  print READBACKSVFFILE "// Wait to initialize the reader and check first word\n";
  print READBACKSVFFILE "RUNTEST 120 TCK;\n";
  $word = substr($mcsDataHex,0,8);
  print READBACKSVFFILE "SDR 33 TDI(0) TDO(1$word) MASK(1FFFFFFFF);\n";
  print READBACKSVFFILE "// Read each word\n";
  $i  = 4;
  while ($i < $mcsDataLength)
  {
    print READBACKSVFFILE "RUNTEST 60 TCK;\n";
    $word = substr($mcsDataHex,($i*2),8);
    print READBACKSVFFILE "SDR 33 TDI(0) TDO(1$word) MASK(1FFFFFFFF);\n";
    $i = $i + 4;
  }
  print READBACKSVFFILE "STATE RESET;\n";
  close(READBACKSVFFILE);
}

# Prepare to write READID SVF file
if (!open(READIDSVFFILE, ">$fileNameReadIdSvf"))
{
  print "ERROR:  Cannot open .SVF file:  $fileNameReadIdSvf\n";
  die;
}
else
{
  print "INFO:  Writing SVF file:  $fileNameReadIdSvf\n";

  print READIDSVFFILE "$HirTirHdrTdr\n";
  print READIDSVFFILE "STATE RESET;\n";
  print READIDSVFFILE "ENDIR IDLE;\n";
  print READIDSVFFILE "ENDDR IDLE;\n";
  print READIDSVFFILE "// Load USER2 instruction to access the SpiFlashReader\n";
  print READIDSVFFILE "SIR $cJtagIRLength TDI($cJtagUser2);\n";
  print READIDSVFFILE "// Load READID start address\n";
  print READIDSVFFILE "SDR 33 TDI(0FFFFFFFF);\n";
  print READIDSVFFILE "// Wait to initialize the reader and check the ID\n";
  print READIDSVFFILE "RUNTEST 120 TCK;\n";
  print READIDSVFFILE "SDR 33 TDI(0) TDO(100$cIdcode24) MASK(100$cIdcodeMask24);\n";
  print READIDSVFFILE "STATE RESET;\n";
  close(READIDSVFFILE);
}

